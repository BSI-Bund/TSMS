# ServiceProvider

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**UUID**](UUID.md) | Unique identification of the SP. |  [optional]
**name** | **String** | Name of the SP. | 
