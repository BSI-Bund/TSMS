# GeneralError

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**errorCategory** | **Integer** | The error type. | 
**errorMessage** | **String** | A human-readable error description in English. | 
