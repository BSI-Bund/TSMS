var spec = {
  "openapi" : "3.0.0",
  "info" : {
    "title" : "BSI-TR-03165: TSM-Backend",
    "description" : "A graphical representation of the TSM-Backend API for a TSMS (Trusted Service Management System) using Swagger UI is presented here. This is to be seen as a supplement to the [BSI-TR-03165](https://www.bsi.bund.de/DE/Themen/Unternehmen-und-Organisationen/Standards-und-Zertifizierung/Technische-Richtlinien/TR-nach-Thema-sortiert/tr03165/tr-03165.html). In case of discrepancies, the content of the written guideline applies.\n\nA TSM-Backend is an IT-system of a TSM that provides TSM-services in form of a REST-API. It acts as a repository for secure applications in different Flavors, configurations, and resources that are necessary to install a secure application. It allows service providers to create, read, update and delete all data objects that are necessary to enable the life-cycle management of their secure application on secure components.\n\n__Functionality:__\n* upload JavaCard *.cap files to TSM-Backend\n* define a service which consists of one or multiple *.cap files\n* versionize the service\n* define hardware variants for each service - called flavors \n* specify technical requirements for each flavor, e.g. minimal JavaCard version\n",
    "termsOfService" : "https://www.bsi.bund.de/DE/Service/Nutzungsbedingungen/Nutzungsbedingungen_node.html",
    "contact" : {
      "email" : "mobile-eid@bsi.bund.de"
    },
    "license" : {
      "name" : "Apache License, Version 2.0",
      "url" : "http://www.apache.org/licenses/LICENSE-2.0.html"
    },
    "version" : "1.0"
  },
  "servers" : [ {
    "url" : "/"
  } ],
  "tags" : [ {
    "name" : "/auth",
    "description" : "authentication methods"
  }, {
    "name" : "/serviceproviders",
    "description" : "methods for management of SP"
  }, {
    "name" : "/secure-component-profiles",
    "description" : "Retrieve SecureComponentProfiles"
  }, {
    "name" : "/services",
    "description" : "methods for management of Services and Flavors"
  }, {
    "name" : "/executable-load-files",
    "description" : "methods for management of ELFs and EMs"
  }, {
    "name" : "/application-configs",
    "description" : "methods for management of ApplicationConfigurations"
  }, {
    "name" : "/personalization-scripts",
    "description" : "methods for management of PersonalizationScripts"
  }, {
    "name" : "/certificates",
    "description" : "methods for management of Certificates"
  }, {
    "name" : "/spos-configs",
    "description" : "methods for management of SposConfigs"
  } ],
  "paths" : {
    "/auth" : {
      "post" : {
        "tags" : [ "/auth" ],
        "summary" : "Authenticate to the TSM-Backend by sending a long-term token, and...",
        "description" : "Authenticate to the TSM-Backend by sending a long-term token, and receive a short-term bearer token. The short-term bearer token is used to access the other API functions. The long-term token is provided out of band.",
        "operationId" : "createAccessToken",
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/auth-Token"
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - returned error category: 1002",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1002,
                  "errorMessage" : "Invalid: request body not allowed."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1001",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1001,
                  "errorMessage" : "Authentication failed."
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "LongtermToken" : [ ]
        } ]
      }
    },
    "/serviceproviders/current" : {
      "get" : {
        "tags" : [ "/serviceproviders" ],
        "summary" : "Get details of the SP account.",
        "description" : "Get details of the SP account.",
        "operationId" : "getAccountInformation",
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/ServiceProvider"
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - returned error category: 1002",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1002,
                  "errorMessage" : "Invalid: request body not allowed."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/secure-component-profiles" : {
      "get" : {
        "tags" : [ "/secure-component-profiles" ],
        "summary" : "List all available SecureComponentProfiles.",
        "description" : "List all available SecureComponentProfiles.",
        "operationId" : "listSecureComponentProfiles",
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "type" : "array",
                  "items" : {
                    "$ref" : "#/components/schemas/SecureComponentProfile"
                  }
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - returned error category: 1002",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1002,
                  "errorMessage" : "Invalid: request body not allowed."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/secure-component-profiles/{scpId}" : {
      "get" : {
        "tags" : [ "/secure-component-profiles" ],
        "summary" : "Get details of a certain SecureComponentProfile.",
        "description" : "Get details of a certain SecureComponentProfile.",
        "operationId" : "getSecureComponentProfile",
        "parameters" : [ {
          "name" : "scpId",
          "in" : "path",
          "description" : "identifier of the referred Scp",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "bc675568-34ac-40b0-abc0-03929b2d5ccd"
          }
        } ],
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/SecureComponentProfile"
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1009,
                  "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/secure-component-profiles/{scpId}/elfs" : {
      "get" : {
        "tags" : [ "/secure-component-profiles" ],
        "summary" : "List all ELFs that use a certain SecureComponentProfile.",
        "description" : "List all ELFs that use a certain SecureComponentProfile.",
        "operationId" : "listScpRelatedElfs",
        "parameters" : [ {
          "name" : "scpId",
          "in" : "path",
          "description" : "identifier of the referred Scp",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "bc675568-34ac-40b0-abc0-03929b2d5ccd"
          }
        } ],
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "type" : "array",
                  "items" : {
                    "$ref" : "#/components/schemas/ExecutableLoadFile"
                  }
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1009,
                  "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/secure-component-profiles/{scpId}/services" : {
      "get" : {
        "tags" : [ "/secure-component-profiles" ],
        "summary" : "List all Services that use a certain SecureComponentProfile.",
        "description" : "List all Services that use a certain SecureComponentProfile.",
        "operationId" : "listScpRelatedServices",
        "parameters" : [ {
          "name" : "scpId",
          "in" : "path",
          "description" : "identifier of the referred Scp",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "bc675568-34ac-40b0-abc0-03929b2d5ccd"
          }
        } ],
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "type" : "array",
                  "items" : {
                    "$ref" : "#/components/schemas/Service"
                  }
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1009,
                  "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/secure-component-profiles/{scpId}/services/{serviceId}/flavors" : {
      "get" : {
        "tags" : [ "/secure-component-profiles" ],
        "summary" : "List all Flavors of a certain Service that use a certain SecureCo...",
        "description" : "List all Flavors of a certain Service that use a certain SecureComponentProfile.",
        "operationId" : "listScpRelatedFlavors",
        "parameters" : [ {
          "name" : "scpId",
          "in" : "path",
          "description" : "identifier of the referred Scp",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "bc675568-34ac-40b0-abc0-03929b2d5ccd"
          }
        }, {
          "name" : "serviceId",
          "in" : "path",
          "description" : "identifier of the referred Service",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "e59d3d32-6756-76ac-ffff-feeba10c081a"
          }
        } ],
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "type" : "array",
                  "items" : {
                    "$ref" : "#/components/schemas/Flavor"
                  }
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1009,
                  "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/secure-component-profiles/{scpId}/services/{serviceId}/versions" : {
      "get" : {
        "tags" : [ "/secure-component-profiles" ],
        "summary" : "List all Versions of a certain Service that use a certain SecureC...",
        "description" : "List all Versions of a certain Service that use a certain SecureComponentProfile.",
        "operationId" : "listScpRelatedVersions",
        "parameters" : [ {
          "name" : "scpId",
          "in" : "path",
          "description" : "identifier of the referred Scp",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "bc675568-34ac-40b0-abc0-03929b2d5ccd"
          }
        }, {
          "name" : "serviceId",
          "in" : "path",
          "description" : "identifier of the referred Service",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "e59d3d32-6756-76ac-ffff-feeba10c081a"
          }
        } ],
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "type" : "array",
                  "items" : {
                    "$ref" : "#/components/schemas/Version"
                  }
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1009,
                  "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/services" : {
      "get" : {
        "tags" : [ "/services" ],
        "summary" : "List all Services of the authenticated ServiceProvider.",
        "description" : "List all Services of the authenticated ServiceProvider.",
        "operationId" : "listServices",
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "type" : "array",
                  "items" : {
                    "$ref" : "#/components/schemas/Service"
                  }
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - returned error category: 1002",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1002,
                  "errorMessage" : "Invalid: request body not allowed."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      },
      "post" : {
        "tags" : [ "/services" ],
        "summary" : "Create a new Service.",
        "description" : "Create a new Service.",
        "operationId" : "createService",
        "requestBody" : {
          "content" : {
            "application/json" : {
              "schema" : {
                "$ref" : "#/components/schemas/Service"
              },
              "example" : {
                "name" : "authDeviceByBNE",
                "accessAuthorizedDeviceApps" : [ "A00000021784013C0110", "A00000007220548C0001", "A00000033467106C1111" ],
                "sposConfigId" : "62d2a5d8-f591-f9ec-32b3-558047c576a7",
                "spParameters" : {
                  "param0" : "Value0 which can be evaluated by the App.",
                  "param1" : "Value1 which can be evaluated by the App.",
                  "param2" : "Value2 which can be evaluated by the App."
                }
              }
            }
          },
          "required" : true
        },
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/Service"
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1003, 1004, 1007, 1008, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1003,
                  "errorMessage" : "Create failed: attribute <<attributeName>> not allowed for POST. It is automatically assigned when created."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/services/{serviceId}" : {
      "get" : {
        "tags" : [ "/services" ],
        "summary" : "Get details of a certain Service.",
        "description" : "Get details of a certain Service.",
        "operationId" : "getService",
        "parameters" : [ {
          "name" : "serviceId",
          "in" : "path",
          "description" : "identifier of the referred Service",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "e59d3d32-6756-76ac-ffff-feeba10c081a"
          }
        } ],
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/Service"
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1009,
                  "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      },
      "put" : {
        "tags" : [ "/services" ],
        "summary" : "Update details of an existing Service.",
        "description" : "Update details of an existing Service.",
        "operationId" : "modifyService",
        "parameters" : [ {
          "name" : "serviceId",
          "in" : "path",
          "description" : "identifier of the referred Service",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "e59d3d32-6756-76ac-ffff-feeba10c081a"
          }
        } ],
        "requestBody" : {
          "content" : {
            "application/json" : {
              "schema" : {
                "$ref" : "#/components/schemas/Service"
              },
              "example" : {
                "name" : "authDeviceByBNE",
                "accessAuthorizedDeviceApps" : [ "A00000021784013C0110", "A00000007220548C0001", "A00000033467106C1111" ],
                "sposConfigId" : "62d2a5d8-f591-f9ec-32b3-558047c576a7",
                "spParameters" : {
                  "param0" : "Value0 which can be evaluated by the App.",
                  "param1" : "Value1 which can be evaluated by the App.",
                  "param2" : "Value2 which can be evaluated by the App."
                }
              }
            }
          },
          "required" : true
        },
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/Service"
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1005, 1006, 1007, 1008, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1005,
                  "errorMessage" : "Modify failed: attribute <<attributeName>> not allowed for PUT. Attribute cannot be modified after creation."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      },
      "delete" : {
        "tags" : [ "/services" ],
        "summary" : "Delete a certain Service. All data, including associated Versions...",
        "description" : "Delete a certain Service. All data, including associated Versions, Flavors, and ApplicationInstantiationConfigs is deleted. Referenced ELFs, ApplicationConfigs, and SposConfigs are not deleted.",
        "operationId" : "deleteService",
        "parameters" : [ {
          "name" : "serviceId",
          "in" : "path",
          "description" : "identifier of the referred Service",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "e59d3d32-6756-76ac-ffff-feeba10c081a"
          }
        } ],
        "responses" : {
          "204" : {
            "description" : "item deleted sucessfully"
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1009,
                  "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/services/{serviceId}/flavors" : {
      "get" : {
        "tags" : [ "/services" ],
        "summary" : "List all Flavors of a certain Service.",
        "description" : "List all Flavors of a certain Service.",
        "operationId" : "listFlavors",
        "parameters" : [ {
          "name" : "serviceId",
          "in" : "path",
          "description" : "identifier of the referred Service",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "e59d3d32-6756-76ac-ffff-feeba10c081a"
          }
        } ],
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "type" : "array",
                  "items" : {
                    "$ref" : "#/components/schemas/Flavor"
                  }
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1009,
                  "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      },
      "post" : {
        "tags" : [ "/services" ],
        "summary" : "Create a new Flavor for a certain Service.",
        "description" : "Create a new Flavor for a certain Service.",
        "operationId" : "createFlavor",
        "parameters" : [ {
          "name" : "serviceId",
          "in" : "path",
          "description" : "identifier of the referred Service",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "e59d3d32-6756-76ac-ffff-feeba10c081a"
          }
        } ],
        "requestBody" : {
          "content" : {
            "application/json" : {
              "schema" : {
                "$ref" : "#/components/schemas/Flavor"
              },
              "example" : {
                "name" : "YY-624B-11",
                "description" : "Additional description for this Flavor.",
                "executableLoadFileIds" : [ "54050ff0-7d9e-ef28-b120-3c3e81ae77af", "7860e9a9-70b3-43b1-b2d7-fc6199c92cb4", "2b3447ca-eecc-eba9-3f48-2f61ae43c742" ],
                "applicationInstantiationConfigs" : [ {
                  "priority" : 137,
                  "executableModuleId" : "40b455b5-1e45-fd2f-319b-83794b2a8d82",
                  "applicationConfigId" : "1e555fae-c0bb-9915-b086-b7f77a52ca69"
                }, {
                  "priority" : 81,
                  "executableModuleId" : "efe37b02-819a-9dc1-f656-b00b80072581",
                  "applicationConfigId" : "9b2990c9-59b0-a979-d4b2-11ff5fe00cb2"
                }, {
                  "priority" : 132,
                  "executableModuleId" : "105030db-8fd7-095f-953e-a4143a3576c3",
                  "applicationConfigId" : "b3f08e86-ebed-1a72-984d-8030cbe89b79"
                } ],
                "spParameters" : {
                  "param0" : "Value0 which can be evaluated by the App.",
                  "param1" : "Value1 which can be evaluated by the App.",
                  "param2" : "Value2 which can be evaluated by the App."
                },
                "contextSpecificAttributes" : {
                  "param0" : "Value0 which can be evaluated by the App.",
                  "param1" : "Value1 which can be evaluated by the App.",
                  "param2" : "Value2 which can be evaluated by the App."
                }
              }
            }
          },
          "required" : true
        },
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/Flavor"
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1003, 1004, 1007, 1008, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1003,
                  "errorMessage" : "Create failed: attribute <<attributeName>> not allowed for POST. It is automatically assigned when created."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/services/{serviceId}/flavors/{flavorId}" : {
      "get" : {
        "tags" : [ "/services" ],
        "summary" : "Get details of a certain Flavor.",
        "description" : "Get details of a certain Flavor.",
        "operationId" : "getFlavor",
        "parameters" : [ {
          "name" : "serviceId",
          "in" : "path",
          "description" : "identifier of the referred Service",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "e59d3d32-6756-76ac-ffff-feeba10c081a"
          }
        }, {
          "name" : "flavorId",
          "in" : "path",
          "description" : "identifier of the referred Flavor",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "ff686d37-4674-1456-26fa-c9ed658bb41c"
          }
        } ],
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/Flavor"
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1009,
                  "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      },
      "put" : {
        "tags" : [ "/services" ],
        "summary" : "Update details of an existing Flavor.",
        "description" : "Update details of an existing Flavor.",
        "operationId" : "modifyFlavor",
        "parameters" : [ {
          "name" : "serviceId",
          "in" : "path",
          "description" : "identifier of the referred Service",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "e59d3d32-6756-76ac-ffff-feeba10c081a"
          }
        }, {
          "name" : "flavorId",
          "in" : "path",
          "description" : "identifier of the referred Flavor",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "ff686d37-4674-1456-26fa-c9ed658bb41c"
          }
        } ],
        "requestBody" : {
          "content" : {
            "application/json" : {
              "schema" : {
                "$ref" : "#/components/schemas/Flavor"
              },
              "example" : {
                "name" : "YY-624B-11",
                "description" : "Additional description for this Flavor.",
                "executableLoadFileIds" : [ "54050ff0-7d9e-ef28-b120-3c3e81ae77af", "7860e9a9-70b3-43b1-b2d7-fc6199c92cb4", "2b3447ca-eecc-eba9-3f48-2f61ae43c742" ],
                "applicationInstantiationConfigs" : [ {
                  "priority" : 137,
                  "executableModuleId" : "40b455b5-1e45-fd2f-319b-83794b2a8d82",
                  "applicationConfigId" : "1e555fae-c0bb-9915-b086-b7f77a52ca69"
                }, {
                  "priority" : 81,
                  "executableModuleId" : "efe37b02-819a-9dc1-f656-b00b80072581",
                  "applicationConfigId" : "9b2990c9-59b0-a979-d4b2-11ff5fe00cb2"
                }, {
                  "priority" : 132,
                  "executableModuleId" : "105030db-8fd7-095f-953e-a4143a3576c3",
                  "applicationConfigId" : "b3f08e86-ebed-1a72-984d-8030cbe89b79"
                } ],
                "spParameters" : {
                  "param0" : "Value0 which can be evaluated by the App.",
                  "param1" : "Value1 which can be evaluated by the App.",
                  "param2" : "Value2 which can be evaluated by the App."
                },
                "contextSpecificAttributes" : {
                  "param0" : "Value0 which can be evaluated by the App.",
                  "param1" : "Value1 which can be evaluated by the App.",
                  "param2" : "Value2 which can be evaluated by the App."
                }
              }
            }
          },
          "required" : true
        },
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/Flavor"
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1005, 1006, 1007, 1008, 1009, 1015, 1016",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1015,
                  "errorMessage" : "Already Published: <<entityName>> cannot be modified. It is already published via Flavor identifier ‘<<attributeValue>>’."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      },
      "delete" : {
        "tags" : [ "/services" ],
        "summary" : "Delete a certain Flavor. All data, including associated Applicati...",
        "description" : "Delete a certain Flavor. All data, including associated ApplicationInstantiationConfigs, is deleted. Referenced ELFs and ApplicationConfigs are not deleted. Deletion SHALL only be possible if the Flavor is not referenced in any Version and thus is not in use anywhere.",
        "operationId" : "deleteFlavor",
        "parameters" : [ {
          "name" : "serviceId",
          "in" : "path",
          "description" : "identifier of the referred Service",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "e59d3d32-6756-76ac-ffff-feeba10c081a"
          }
        }, {
          "name" : "flavorId",
          "in" : "path",
          "description" : "identifier of the referred Flavor",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "ff686d37-4674-1456-26fa-c9ed658bb41c"
          }
        } ],
        "responses" : {
          "204" : {
            "description" : "item deleted sucessfully"
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009, 1010",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1010,
                  "errorMessage" : "Delete failed: <<entityName>> is referenced in <<entityNameWhereUsed>>."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/services/{serviceId}/flavors/{flavorId}/application-configs" : {
      "get" : {
        "tags" : [ "/services" ],
        "summary" : "List all ApplicationConfigs that use a certain Flavor.",
        "description" : "List all ApplicationConfigs that use a certain Flavor.",
        "operationId" : "listServiceRelatedAppConfigs",
        "parameters" : [ {
          "name" : "serviceId",
          "in" : "path",
          "description" : "identifier of the referred Service",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "e59d3d32-6756-76ac-ffff-feeba10c081a"
          }
        }, {
          "name" : "flavorId",
          "in" : "path",
          "description" : "identifier of the referred Flavor",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "ff686d37-4674-1456-26fa-c9ed658bb41c"
          }
        } ],
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "type" : "array",
                  "items" : {
                    "$ref" : "#/components/schemas/ApplicationConfig"
                  }
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1009,
                  "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/services/{serviceId}/flavors/{flavorId}/executable-load-files" : {
      "get" : {
        "tags" : [ "/services" ],
        "summary" : "List all ExecutableLoadFiles used by a certain Flavor.",
        "description" : "List all ExecutableLoadFiles used by a certain Flavor.",
        "operationId" : "listLinkedElfs",
        "parameters" : [ {
          "name" : "serviceId",
          "in" : "path",
          "description" : "identifier of the referred Service",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "e59d3d32-6756-76ac-ffff-feeba10c081a"
          }
        }, {
          "name" : "flavorId",
          "in" : "path",
          "description" : "identifier of the referred Flavor",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "ff686d37-4674-1456-26fa-c9ed658bb41c"
          }
        } ],
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "type" : "array",
                  "items" : {
                    "$ref" : "#/components/schemas/ExecutableLoadFile"
                  }
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1009,
                  "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      },
      "put" : {
        "tags" : [ "/services" ],
        "summary" : "Remove ExecutableLoadFiles from a certain Flavor. In case ELF Ids...",
        "description" : "Remove ExecutableLoadFiles from a certain Flavor. In case ELF Ids provided are not linked to this Flavor, method will still be successful.",
        "operationId" : "unlinkElfs",
        "parameters" : [ {
          "name" : "serviceId",
          "in" : "path",
          "description" : "identifier of the referred Service",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "e59d3d32-6756-76ac-ffff-feeba10c081a"
          }
        }, {
          "name" : "flavorId",
          "in" : "path",
          "description" : "identifier of the referred Flavor",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "ff686d37-4674-1456-26fa-c9ed658bb41c"
          }
        } ],
        "requestBody" : {
          "description" : "Ids of the ELFs to be removed from the flavor (elfIds)",
          "content" : {
            "application/json" : {
              "schema" : {
                "type" : "array",
                "items" : {
                  "type" : "string"
                }
              }
            }
          },
          "required" : true
        },
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/Flavor"
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1008, 1009, 1015",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1008,
                  "errorMessage" : "Invalid format '<<attributeValue>>' for << attributeName>>. Supported format is <<formatDefinition>>."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      },
      "post" : {
        "tags" : [ "/services" ],
        "summary" : "Add additional ExecutableLoadFiles to a certain Flavor. In case E...",
        "description" : "Add additional ExecutableLoadFiles to a certain Flavor. In case ELF Ids provided are already linked to this Flavor, method will still be successful.",
        "operationId" : "linkElfs",
        "parameters" : [ {
          "name" : "serviceId",
          "in" : "path",
          "description" : "identifier of the referred Service",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "e59d3d32-6756-76ac-ffff-feeba10c081a"
          }
        }, {
          "name" : "flavorId",
          "in" : "path",
          "description" : "identifier of the referred Flavor",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "ff686d37-4674-1456-26fa-c9ed658bb41c"
          }
        } ],
        "requestBody" : {
          "description" : "Ids of the ELFs to be added to the flavor (elfIds)",
          "content" : {
            "application/json" : {
              "schema" : {
                "type" : "array",
                "items" : {
                  "type" : "string"
                }
              }
            }
          },
          "required" : true
        },
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/Flavor"
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1008, 1009, 1015, 1016",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1015,
                  "errorMessage" : "Already Published: <<entityName>> cannot be modified. It is already published via Flavor identifier ‘<<attributeValue>>’."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/services/{serviceId}/flavors/{flavorId}/publish" : {
      "post" : {
        "tags" : [ "/services" ],
        "summary" : "Publish a Flavor. After publishing, the Flavor can be used for in...",
        "description" : "Publish a Flavor. After publishing, the Flavor can be used for installation on a handset and certain attributes cannot be modified anymore (see Section 4.1.6.4.6). The publishing status of a Flavor can be checked with the attribute publish of the Flavor. When a Flavor is once published, it is not possible to undo this process. It is valid to call this method multiple times, even if a Flavor is already published.",
        "operationId" : "publishFlavor",
        "parameters" : [ {
          "name" : "serviceId",
          "in" : "path",
          "description" : "identifier of the referred Service",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "e59d3d32-6756-76ac-ffff-feeba10c081a"
          }
        }, {
          "name" : "flavorId",
          "in" : "path",
          "description" : "identifier of the referred Flavor",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "ff686d37-4674-1456-26fa-c9ed658bb41c"
          }
        } ],
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/Flavor"
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1009,
                  "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/services/{serviceId}/flavors/{flavorId}/versions" : {
      "get" : {
        "tags" : [ "/services" ],
        "summary" : "List all Versions that use a certain Flavor.",
        "description" : "List all Versions that use a certain Flavor.",
        "operationId" : "listServiceRelatedVersions",
        "parameters" : [ {
          "name" : "serviceId",
          "in" : "path",
          "description" : "identifier of the referred Service",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "e59d3d32-6756-76ac-ffff-feeba10c081a"
          }
        }, {
          "name" : "flavorId",
          "in" : "path",
          "description" : "identifier of the referred Flavor",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "ff686d37-4674-1456-26fa-c9ed658bb41c"
          }
        } ],
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "type" : "array",
                  "items" : {
                    "$ref" : "#/components/schemas/Version"
                  }
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1009,
                  "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/services/{serviceId}/versions" : {
      "get" : {
        "tags" : [ "/services" ],
        "summary" : "List all Versions of a certain Service.",
        "description" : "List all Versions of a certain Service.",
        "operationId" : "listVersions",
        "parameters" : [ {
          "name" : "serviceId",
          "in" : "path",
          "description" : "identifier of the referred Service",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "e59d3d32-6756-76ac-ffff-feeba10c081a"
          }
        } ],
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "type" : "array",
                  "items" : {
                    "$ref" : "#/components/schemas/Version"
                  }
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1009,
                  "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      },
      "post" : {
        "tags" : [ "/services" ],
        "summary" : "Create a new Version of a certain Service.",
        "description" : "Create a new Version of a certain Service.",
        "operationId" : "createVersion",
        "parameters" : [ {
          "name" : "serviceId",
          "in" : "path",
          "description" : "identifier of the referred Service",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "e59d3d32-6756-76ac-ffff-feeba10c081a"
          }
        } ],
        "requestBody" : {
          "content" : {
            "application/json" : {
              "schema" : {
                "$ref" : "#/components/schemas/Version"
              },
              "example" : {
                "allowedDeployments" : [ "c207b03f-75c5-c5ff-2460-fe6cec8ab803", "ca85a700-9b54-e89a-8b3f-60296b75c26f", "553e809b-5610-53f0-ed91-5a12fa0e65ac" ]
              }
            }
          },
          "required" : true
        },
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/Version"
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1003, 1004, 1007, 1008, 1009, 1016",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1004,
                  "errorMessage" : "Create failed: attribute <<attributeName>> is missing, but it is mandatory for <<entityName>>."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/services/{serviceId}/versions/{tag}" : {
      "get" : {
        "tags" : [ "/services" ],
        "summary" : "Get details of a certain Version.",
        "description" : "Get details of a certain Version.",
        "operationId" : "getVersion",
        "parameters" : [ {
          "name" : "serviceId",
          "in" : "path",
          "description" : "identifier of the referred Service",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "e59d3d32-6756-76ac-ffff-feeba10c081a"
          }
        }, {
          "name" : "tag",
          "in" : "path",
          "description" : "identifier of the referred Tag",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 11,
            "minLength" : 5,
            "pattern" : "^\\d{1,3}.\\d{1,3}.\\d{1,3}$",
            "type" : "string",
            "format" : "version",
            "example" : "4.31.005"
          }
        } ],
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/Version"
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1009,
                  "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      },
      "put" : {
        "tags" : [ "/services" ],
        "summary" : "Update details of an existing Version.",
        "description" : "Update details of an existing Version.",
        "operationId" : "modifyVersion",
        "parameters" : [ {
          "name" : "serviceId",
          "in" : "path",
          "description" : "identifier of the referred Service",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "e59d3d32-6756-76ac-ffff-feeba10c081a"
          }
        }, {
          "name" : "tag",
          "in" : "path",
          "description" : "identifier of the referred Tag",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 11,
            "minLength" : 5,
            "pattern" : "^\\d{1,3}.\\d{1,3}.\\d{1,3}$",
            "type" : "string",
            "format" : "version",
            "example" : "4.31.005"
          }
        } ],
        "requestBody" : {
          "content" : {
            "application/json" : {
              "schema" : {
                "$ref" : "#/components/schemas/Version"
              },
              "example" : {
                "allowedDeployments" : [ "c207b03f-75c5-c5ff-2460-fe6cec8ab803", "ca85a700-9b54-e89a-8b3f-60296b75c26f", "553e809b-5610-53f0-ed91-5a12fa0e65ac" ]
              }
            }
          },
          "required" : true
        },
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/Version"
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1005, 1006, 1007, 1008, 1009, 1016",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1016,
                  "errorMessage" : "Technical constraints failed: minimal <<attributeName>> version not supported by SecureComponentProfile."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      },
      "delete" : {
        "tags" : [ "/services" ],
        "summary" : "Delete a certain Version. All data is deleted. Referenced Flavors...",
        "description" : "Delete a certain Version. All data is deleted. Referenced Flavors are not deleted.",
        "operationId" : "deleteVersion",
        "parameters" : [ {
          "name" : "serviceId",
          "in" : "path",
          "description" : "identifier of the referred Service",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "e59d3d32-6756-76ac-ffff-feeba10c081a"
          }
        }, {
          "name" : "tag",
          "in" : "path",
          "description" : "identifier of the referred Tag",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 11,
            "minLength" : 5,
            "pattern" : "^\\d{1,3}.\\d{1,3}.\\d{1,3}$",
            "type" : "string",
            "format" : "version",
            "example" : "4.31.005"
          }
        } ],
        "responses" : {
          "204" : {
            "description" : "item deleted sucessfully"
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009, 1010",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1010,
                  "errorMessage" : "Delete failed: <<entityName>> is referenced in <<entityNameWhereUsed>>."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/services/{serviceId}/versions/{tag}/flavors" : {
      "get" : {
        "tags" : [ "/services" ],
        "summary" : "List all Flavors used by a certain Version.",
        "description" : "List all Flavors used by a certain Version.",
        "operationId" : "listLinkedFlavors",
        "parameters" : [ {
          "name" : "serviceId",
          "in" : "path",
          "description" : "identifier of the referred Service",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "e59d3d32-6756-76ac-ffff-feeba10c081a"
          }
        }, {
          "name" : "tag",
          "in" : "path",
          "description" : "identifier of the referred Tag",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 11,
            "minLength" : 5,
            "pattern" : "^\\d{1,3}.\\d{1,3}.\\d{1,3}$",
            "type" : "string",
            "format" : "version",
            "example" : "4.31.005"
          }
        } ],
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "type" : "array",
                  "items" : {
                    "$ref" : "#/components/schemas/Flavor"
                  }
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1009,
                  "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      },
      "put" : {
        "tags" : [ "/services" ],
        "summary" : "Remove Flavors from a certain Version. In case Flavor Ids provide...",
        "description" : "Remove Flavors from a certain Version. In case Flavor Ids provided are not linked to this Version, method will still be successful.",
        "operationId" : "unlinkFlavors",
        "parameters" : [ {
          "name" : "serviceId",
          "in" : "path",
          "description" : "identifier of the referred Service",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "e59d3d32-6756-76ac-ffff-feeba10c081a"
          }
        }, {
          "name" : "tag",
          "in" : "path",
          "description" : "identifier of the referred Tag",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 11,
            "minLength" : 5,
            "pattern" : "^\\d{1,3}.\\d{1,3}.\\d{1,3}$",
            "type" : "string",
            "format" : "version",
            "example" : "4.31.005"
          }
        } ],
        "requestBody" : {
          "description" : "Ids of the flavors to be removed from the version (flavorIds)",
          "content" : {
            "application/json" : {
              "schema" : {
                "type" : "array",
                "items" : {
                  "type" : "string"
                }
              }
            }
          },
          "required" : true
        },
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/Version"
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1008, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1008,
                  "errorMessage" : "Invalid format '<<attributeValue>>' for << attributeName>>. Supported format is <<formatDefinition>>."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      },
      "post" : {
        "tags" : [ "/services" ],
        "summary" : "Add additional Flavors to a certain Version and configure the Sec...",
        "description" : "Add additional Flavors to a certain Version and configure the SecureComponentProfiles supported by the Flavor. In case Flavor Ids provided are already linked to this Version, the method will still be successful and it will just modify the list of supported SecureComponentProfiles.",
        "operationId" : "linkFlavors",
        "parameters" : [ {
          "name" : "serviceId",
          "in" : "path",
          "description" : "identifier of the referred Service",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "e59d3d32-6756-76ac-ffff-feeba10c081a"
          }
        }, {
          "name" : "tag",
          "in" : "path",
          "description" : "identifier of the referred Tag",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 11,
            "minLength" : 5,
            "pattern" : "^\\d{1,3}.\\d{1,3}.\\d{1,3}$",
            "type" : "string",
            "format" : "version",
            "example" : "4.31.005"
          }
        } ],
        "requestBody" : {
          "description" : "Map keys: flavorIds, Map values: list of secureComponentProfileIds",
          "content" : {
            "application/json" : {
              "schema" : {
                "type" : "object",
                "additionalProperties" : {
                  "type" : "array",
                  "items" : {
                    "maxLength" : 255,
                    "type" : "string"
                  }
                }
              }
            }
          },
          "required" : true
        },
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/Version"
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1008, 1009, 1016",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1016,
                  "errorMessage" : "Technical constraints failed: minimal <<attributeName>> version not supported by SecureComponentProfile."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/services/{serviceId}/versions/{tag}/flavors/{flavorId}/secure-component-profiles" : {
      "get" : {
        "tags" : [ "/services" ],
        "summary" : "List SecureComponentProfiles associated to a certain Flavor of a ...",
        "description" : "List SecureComponentProfiles associated to a certain Flavor of a certain Version.",
        "operationId" : "listAssociatedSecureComponentProfiles",
        "parameters" : [ {
          "name" : "serviceId",
          "in" : "path",
          "description" : "identifier of the referred Service",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "e59d3d32-6756-76ac-ffff-feeba10c081a"
          }
        }, {
          "name" : "tag",
          "in" : "path",
          "description" : "identifier of the referred Tag",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 11,
            "minLength" : 5,
            "pattern" : "^\\d{1,3}.\\d{1,3}.\\d{1,3}$",
            "type" : "string",
            "format" : "version",
            "example" : "4.31.005"
          }
        }, {
          "name" : "flavorId",
          "in" : "path",
          "description" : "identifier of the referred Flavor",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "ff686d37-4674-1456-26fa-c9ed658bb41c"
          }
        } ],
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "type" : "array",
                  "items" : {
                    "$ref" : "#/components/schemas/SecureComponentProfile"
                  }
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1009,
                  "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/services/{serviceId}/versions/{tag}/secure-component-profiles" : {
      "get" : {
        "tags" : [ "/services" ],
        "summary" : "List all SecureComponentProfiles used by a certain Version.",
        "description" : "List all SecureComponentProfiles used by a certain Version.",
        "operationId" : "listLinkedSecureComponentProfiles",
        "parameters" : [ {
          "name" : "serviceId",
          "in" : "path",
          "description" : "identifier of the referred Service",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "e59d3d32-6756-76ac-ffff-feeba10c081a"
          }
        }, {
          "name" : "tag",
          "in" : "path",
          "description" : "identifier of the referred Tag",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 11,
            "minLength" : 5,
            "pattern" : "^\\d{1,3}.\\d{1,3}.\\d{1,3}$",
            "type" : "string",
            "format" : "version",
            "example" : "4.31.005"
          }
        } ],
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "type" : "array",
                  "items" : {
                    "$ref" : "#/components/schemas/SecureComponentProfile"
                  }
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1009,
                  "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      },
      "put" : {
        "tags" : [ "/services" ],
        "summary" : "Remove SecureComponentProfiles from a certain Version. In case Se...",
        "description" : "Remove SecureComponentProfiles from a certain Version. In case SecureComponentProfile Ids provided are not linked to this Version, method will still be successful.",
        "operationId" : "unlinkSecureComponentProfiles",
        "parameters" : [ {
          "name" : "serviceId",
          "in" : "path",
          "description" : "identifier of the referred Service",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "e59d3d32-6756-76ac-ffff-feeba10c081a"
          }
        }, {
          "name" : "tag",
          "in" : "path",
          "description" : "identifier of the referred Tag",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 11,
            "minLength" : 5,
            "pattern" : "^\\d{1,3}.\\d{1,3}.\\d{1,3}$",
            "type" : "string",
            "format" : "version",
            "example" : "4.31.005"
          }
        } ],
        "requestBody" : {
          "description" : "Ids of the secureComponentProfiles to be removed from the version (secureComponentProfileIds)",
          "content" : {
            "application/json" : {
              "schema" : {
                "type" : "array",
                "items" : {
                  "type" : "string"
                }
              }
            }
          },
          "required" : true
        },
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/Version"
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1008, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1008,
                  "errorMessage" : "Invalid format '<<attributeValue>>' for << attributeName>>. Supported format is <<formatDefinition>>."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      },
      "post" : {
        "tags" : [ "/services" ],
        "summary" : "Add additional SecureComponentProfiles to a certain Version and c...",
        "description" : "Add additional SecureComponentProfiles to a certain Version and configure the Flavors supported. In case SecureComponentProfile Ids provided are already linked to this Version, the method will still be successful and it will just modify the list of supported Flavors.",
        "operationId" : "linkSecureComponentProfiles",
        "parameters" : [ {
          "name" : "serviceId",
          "in" : "path",
          "description" : "identifier of the referred Service",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "e59d3d32-6756-76ac-ffff-feeba10c081a"
          }
        }, {
          "name" : "tag",
          "in" : "path",
          "description" : "identifier of the referred Tag",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 11,
            "minLength" : 5,
            "pattern" : "^\\d{1,3}.\\d{1,3}.\\d{1,3}$",
            "type" : "string",
            "format" : "version",
            "example" : "4.31.005"
          }
        } ],
        "requestBody" : {
          "description" : "Map keys: secureComponentProfileIds, Map values: list of flavorIds",
          "content" : {
            "application/json" : {
              "schema" : {
                "type" : "object",
                "additionalProperties" : {
                  "type" : "array",
                  "items" : {
                    "maxLength" : 255,
                    "type" : "string"
                  }
                }
              }
            }
          },
          "required" : true
        },
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/Version"
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1008, 1009, 1016",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1016,
                  "errorMessage" : "Technical constraints failed: minimal <<attributeName>> version not supported by SecureComponentProfile."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/executable-load-files" : {
      "get" : {
        "tags" : [ "/executable-load-files" ],
        "summary" : "List all ExecutableLoadFiles of the authenticated ServiceProvider.",
        "description" : "List all ExecutableLoadFiles of the authenticated ServiceProvider.",
        "operationId" : "listElfs",
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "type" : "array",
                  "items" : {
                    "$ref" : "#/components/schemas/ExecutableLoadFile"
                  }
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - returned error category: 1002",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1002,
                  "errorMessage" : "Invalid: request body not allowed."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      },
      "post" : {
        "tags" : [ "/executable-load-files" ],
        "summary" : "Create a new ExecutableLoadFile and upload corresponding binary d...",
        "description" : "Create a new ExecutableLoadFile and upload corresponding binary data. ELF details and binary must both be provided to create a new ExecutableLoadFile.",
        "operationId" : "createElfAndUploadBinary",
        "requestBody" : {
          "$ref" : "#/components/requestBodies/binaryELF"
        },
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/ExecutableLoadFile"
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1003, 1004, 1007, 1008, 1009, 1011, 1012, 1013, 1014",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1013,
                  "errorMessage" : "Upload failed: invalid file type. Supported file types are <<fileTypeList>>."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/executable-load-files/{elfId}" : {
      "get" : {
        "tags" : [ "/executable-load-files" ],
        "summary" : "Get details of a certain ExecutableLoadFile.",
        "description" : "Get details of a certain ExecutableLoadFile.",
        "operationId" : "getElf",
        "parameters" : [ {
          "name" : "elfId",
          "in" : "path",
          "description" : "identifier of the referred Elf",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "c73e8ddc-0318-7940-dc7d-ae5bab5ce549"
          }
        } ],
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/ExecutableLoadFile"
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1009,
                  "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      },
      "put" : {
        "tags" : [ "/executable-load-files" ],
        "summary" : "Update details and overwrite binary data of an existing Executabl...",
        "description" : "Update details and overwrite binary data of an existing ExecutableLoadFile. The binary of an ExecutableLoadFile can only be replaced, as long it is not yet linked to a published Flavor.",
        "operationId" : "modifyElfAndOverwriteBinary",
        "parameters" : [ {
          "name" : "elfId",
          "in" : "path",
          "description" : "identifier of the referred Elf",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "c73e8ddc-0318-7940-dc7d-ae5bab5ce549"
          }
        } ],
        "requestBody" : {
          "$ref" : "#/components/requestBodies/binaryELF"
        },
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/ExecutableLoadFile"
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1005, 1006, 1007, 1008, 1009, 1011, 1012, 1013, 1014, 1015, 1016",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1007,
                  "errorMessage" : "Unknown: ‘<<attributeName>>’ is not a valid attribute."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      },
      "delete" : {
        "tags" : [ "/executable-load-files" ],
        "summary" : "Delete a certain ExecutableLoadFile. All data, including binary d...",
        "description" : "Delete a certain ExecutableLoadFile. All data, including binary data, meta-data, and associated TechnicalRequirements, is deleted. Deletion SHALL only be possible if the ExecutableLoadFile is not referenced in any Flavor and thus is not in use anywhere.",
        "operationId" : "deleteElf",
        "parameters" : [ {
          "name" : "elfId",
          "in" : "path",
          "description" : "identifier of the referred Elf",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "c73e8ddc-0318-7940-dc7d-ae5bab5ce549"
          }
        } ],
        "responses" : {
          "204" : {
            "description" : "item deleted sucessfully"
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009, 1010",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1010,
                  "errorMessage" : "Delete failed: <<entityName>> is referenced in <<entityNameWhereUsed>>."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/executable-load-files/{elfId}/binary" : {
      "get" : {
        "tags" : [ "/executable-load-files" ],
        "summary" : "Get binary data of a certain ExecutableLoadFile.",
        "description" : "Get binary data of a certain ExecutableLoadFile.",
        "operationId" : "getElfBinary",
        "parameters" : [ {
          "name" : "elfId",
          "in" : "path",
          "description" : "identifier of the referred Elf",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "c73e8ddc-0318-7940-dc7d-ae5bab5ce549"
          }
        } ],
        "responses" : {
          "200" : {
            "description" : "Ok",
            "headers" : {
              "Content-Disposition" : {
                "style" : "simple",
                "explode" : false,
                "schema" : {
                  "type" : "string",
                  "example" : "attachment; filename=\"filename.cap\""
                }
              }
            },
            "content" : {
              "application/octet-data" : {
                "schema" : {
                  "type" : "string",
                  "description" : "containing actual elf-binary",
                  "format" : "binary"
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1009,
                  "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/executable-load-files/{elfId}/executable-modules" : {
      "get" : {
        "tags" : [ "/executable-load-files" ],
        "summary" : "List all ExecutableModules of a certain ExecutableLoadFile.",
        "description" : "List all ExecutableModules of a certain ExecutableLoadFile.",
        "operationId" : "listEms",
        "parameters" : [ {
          "name" : "elfId",
          "in" : "path",
          "description" : "identifier of the referred Elf",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "c73e8ddc-0318-7940-dc7d-ae5bab5ce549"
          }
        } ],
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "type" : "array",
                  "items" : {
                    "$ref" : "#/components/schemas/ExecutableModule"
                  }
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1009,
                  "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/executable-load-files/{elfId}/executable-modules/{emId}" : {
      "get" : {
        "tags" : [ "/executable-load-files" ],
        "summary" : "Get details of a certain ExecutableModule of a certain Executable...",
        "description" : "Get details of a certain ExecutableModule of a certain ExecutableLoadFile.",
        "operationId" : "getEm",
        "parameters" : [ {
          "name" : "elfId",
          "in" : "path",
          "description" : "identifier of the referred Elf",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "c73e8ddc-0318-7940-dc7d-ae5bab5ce549"
          }
        }, {
          "name" : "emId",
          "in" : "path",
          "description" : "identifier of the referred Em",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "4079f402-4e86-b4b0-0c4f-a21681ece9c8"
          }
        } ],
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/ExecutableModule"
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1009,
                  "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/executable-load-files/{elfId}/executable-modules/{emId}/application-configs" : {
      "get" : {
        "tags" : [ "/executable-load-files" ],
        "summary" : "Return the ApplicationConfigs that apply to a certain ExecutableM...",
        "description" : "Return the ApplicationConfigs that apply to a certain ExecutableModule.",
        "operationId" : "listElfRelatedAppConfigs",
        "parameters" : [ {
          "name" : "elfId",
          "in" : "path",
          "description" : "identifier of the referred Elf",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "c73e8ddc-0318-7940-dc7d-ae5bab5ce549"
          }
        }, {
          "name" : "emId",
          "in" : "path",
          "description" : "identifier of the referred Em",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "4079f402-4e86-b4b0-0c4f-a21681ece9c8"
          }
        } ],
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "type" : "array",
                  "items" : {
                    "$ref" : "#/components/schemas/ApplicationConfig"
                  }
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1009,
                  "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/services/{serviceId}/executable-load-files/{elfId}/flavors" : {
      "get" : {
        "tags" : [ "/services" ],
        "summary" : "List all Flavors that use a certain ExecutableLoadFile.",
        "description" : "List all Flavors that use a certain ExecutableLoadFile.",
        "operationId" : "listElfRelatedFlavors",
        "parameters" : [ {
          "name" : "serviceId",
          "in" : "path",
          "description" : "identifier of the referred Service",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "e59d3d32-6756-76ac-ffff-feeba10c081a"
          }
        }, {
          "name" : "elfId",
          "in" : "path",
          "description" : "identifier of the referred Elf",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "c73e8ddc-0318-7940-dc7d-ae5bab5ce549"
          }
        } ],
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "type" : "array",
                  "items" : {
                    "$ref" : "#/components/schemas/Flavor"
                  }
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1009,
                  "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/executable-load-files/{elfId}/services" : {
      "get" : {
        "tags" : [ "/executable-load-files" ],
        "summary" : "List all Services that use a certain ExecutableLoadFile.",
        "description" : "List all Services that use a certain ExecutableLoadFile.",
        "operationId" : "listElfRelatedServices",
        "parameters" : [ {
          "name" : "elfId",
          "in" : "path",
          "description" : "identifier of the referred Elf",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "c73e8ddc-0318-7940-dc7d-ae5bab5ce549"
          }
        } ],
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "type" : "array",
                  "items" : {
                    "$ref" : "#/components/schemas/Service"
                  }
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1009,
                  "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/executable-load-files/{elfId}/services/{servideId}/versions" : {
      "get" : {
        "tags" : [ "/executable-load-files" ],
        "summary" : "List all Versions of a certain Service that use a certain Executa...",
        "description" : "List all Versions of a certain Service that use a certain ExecutableLoadFile.",
        "operationId" : "listElfRelatedVersions",
        "parameters" : [ {
          "name" : "elfId",
          "in" : "path",
          "description" : "identifier of the referred Elf",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "c73e8ddc-0318-7940-dc7d-ae5bab5ce549"
          }
        }, {
          "name" : "servideId",
          "in" : "path",
          "description" : "identifier of the referred Servide",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "615c1678-895b-ff21-7c6c-bcd9fed11b84"
          }
        } ],
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "type" : "array",
                  "items" : {
                    "$ref" : "#/components/schemas/Version"
                  }
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1009,
                  "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/executable-load-files/{elfId}/services/{serviceId}/secure-component-profiles" : {
      "get" : {
        "tags" : [ "/executable-load-files" ],
        "summary" : "List all SecureComponentProfiles associated to certain Service th...",
        "description" : "List all SecureComponentProfiles associated to certain Service that use a certain ExecutableLoadFile. The returned list of SecureComponentProfiles SHALL not contain any duplicate entries.",
        "operationId" : "listElfRelatedSecureComponentProfiles",
        "parameters" : [ {
          "name" : "elfId",
          "in" : "path",
          "description" : "identifier of the referred Elf",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "c73e8ddc-0318-7940-dc7d-ae5bab5ce549"
          }
        }, {
          "name" : "serviceId",
          "in" : "path",
          "description" : "identifier of the referred Service",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "e59d3d32-6756-76ac-ffff-feeba10c081a"
          }
        } ],
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "type" : "array",
                  "items" : {
                    "$ref" : "#/components/schemas/SecureComponentProfile"
                  }
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1009,
                  "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/application-configs" : {
      "get" : {
        "tags" : [ "/application-configs" ],
        "summary" : "List all ApplicationConfigs of the authenticated ServiceProvider.",
        "description" : "List all ApplicationConfigs of the authenticated ServiceProvider.",
        "operationId" : "listAppConfigs",
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "type" : "array",
                  "items" : {
                    "$ref" : "#/components/schemas/ApplicationConfig"
                  }
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - returned error category: 1002",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1002,
                  "errorMessage" : "Invalid: request body not allowed."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      },
      "post" : {
        "tags" : [ "/application-configs" ],
        "summary" : "Create a new ApplicationConfig.",
        "description" : "Create a new ApplicationConfig.",
        "operationId" : "createAppConfig",
        "requestBody" : {
          "content" : {
            "application/json" : {
              "schema" : {
                "$ref" : "#/components/schemas/ApplicationConfig"
              },
              "example" : {
                "instanceAid" : "A00000089316631C0000",
                "name" : "XX-413D-58",
                "description" : "Description of this ApplicationConfig."
              }
            }
          },
          "required" : true
        },
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/ApplicationConfig"
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1003, 1004, 1007, 1008, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1003,
                  "errorMessage" : "Create failed: attribute <<attributeName>> not allowed for POST. It is automatically assigned when created."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/application-configs/{applicationConfigId}" : {
      "get" : {
        "tags" : [ "/application-configs" ],
        "summary" : "Get details of a certain ApplicationConfig.",
        "description" : "Get details of a certain ApplicationConfig.",
        "operationId" : "getAppConfig",
        "parameters" : [ {
          "name" : "applicationConfigId",
          "in" : "path",
          "description" : "identifier of the referred ApplicationConfig",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "a0f59df9-7ee2-161f-9325-46e1ecc0ecae"
          }
        } ],
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/ApplicationConfig"
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1009,
                  "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      },
      "put" : {
        "tags" : [ "/application-configs" ],
        "summary" : "Update details of an existing ApplicationConfig.",
        "description" : "Update details of an existing ApplicationConfig.",
        "operationId" : "modifyAppConfig",
        "parameters" : [ {
          "name" : "applicationConfigId",
          "in" : "path",
          "description" : "identifier of the referred ApplicationConfig",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "a0f59df9-7ee2-161f-9325-46e1ecc0ecae"
          }
        } ],
        "requestBody" : {
          "content" : {
            "application/json" : {
              "schema" : {
                "$ref" : "#/components/schemas/ApplicationConfig"
              },
              "example" : {
                "instanceAid" : "A00000089316631C0000",
                "name" : "XX-413D-58",
                "description" : "Description of this ApplicationConfig."
              }
            }
          },
          "required" : true
        },
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/ApplicationConfig"
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1005, 1006, 1007, 1008, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1005,
                  "errorMessage" : "Modify failed: attribute <<attributeName>> not allowed for PUT. Attribute cannot be modified after creation."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      },
      "delete" : {
        "tags" : [ "/application-configs" ],
        "summary" : "Delete a certain ApplicationConfig. All data is deleted. Referenc...",
        "description" : "Delete a certain ApplicationConfig. All data is deleted. Referenced Certificates and PersonalizationScripts are not deleted. Deletion SHALL only be possible if the ApplicationConfig is not referenced in any Flavor and thus is not in use anywhere.",
        "operationId" : "deleteAppConfig",
        "parameters" : [ {
          "name" : "applicationConfigId",
          "in" : "path",
          "description" : "identifier of the referred ApplicationConfig",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "a0f59df9-7ee2-161f-9325-46e1ecc0ecae"
          }
        } ],
        "responses" : {
          "204" : {
            "description" : "item deleted sucessfully"
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009, 1010",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1010,
                  "errorMessage" : "Delete failed: <<entityName>> is referenced in <<entityNameWhereUsed>>."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/application-configs/{applicationConfigId}/executable-modules" : {
      "get" : {
        "tags" : [ "/application-configs" ],
        "summary" : "List all ExecutableModules that use a certain ApplicationConfig.",
        "description" : "List all ExecutableModules that use a certain ApplicationConfig.",
        "operationId" : "listAppConfigRelatedEms",
        "parameters" : [ {
          "name" : "applicationConfigId",
          "in" : "path",
          "description" : "identifier of the referred ApplicationConfig",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "a0f59df9-7ee2-161f-9325-46e1ecc0ecae"
          }
        } ],
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "type" : "array",
                  "items" : {
                    "$ref" : "#/components/schemas/ExecutableModule"
                  }
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1009,
                  "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/application-configs/{applicationConfigId}/flavors" : {
      "get" : {
        "tags" : [ "/application-configs" ],
        "summary" : "List all Flavors that use a certain ApplicationConfig.",
        "description" : "List all Flavors that use a certain ApplicationConfig.",
        "operationId" : "listAppConfigRelatedFlavors",
        "parameters" : [ {
          "name" : "applicationConfigId",
          "in" : "path",
          "description" : "identifier of the referred ApplicationConfig",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "a0f59df9-7ee2-161f-9325-46e1ecc0ecae"
          }
        } ],
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "type" : "array",
                  "items" : {
                    "$ref" : "#/components/schemas/Flavor"
                  }
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1009,
                  "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/application-configs/{applicationConfigId}/services" : {
      "get" : {
        "tags" : [ "/application-configs" ],
        "summary" : "List all Services that use a certain ApplicationConfig.",
        "description" : "List all Services that use a certain ApplicationConfig.",
        "operationId" : "listAppConfigRelatedServices",
        "parameters" : [ {
          "name" : "applicationConfigId",
          "in" : "path",
          "description" : "identifier of the referred ApplicationConfig",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "a0f59df9-7ee2-161f-9325-46e1ecc0ecae"
          }
        } ],
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "type" : "array",
                  "items" : {
                    "$ref" : "#/components/schemas/Service"
                  }
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1009,
                  "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/personalization-scripts" : {
      "get" : {
        "tags" : [ "/personalization-scripts" ],
        "summary" : "List all PersonalizationScripts of the authenticated ServiceProvider.",
        "description" : "List all PersonalizationScripts of the authenticated ServiceProvider.",
        "operationId" : "listPersoScripts",
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "type" : "array",
                  "items" : {
                    "$ref" : "#/components/schemas/PersonalizationScript"
                  }
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - returned error category: 1002",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1002,
                  "errorMessage" : "Invalid: request body not allowed."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      },
      "post" : {
        "tags" : [ "/personalization-scripts" ],
        "summary" : "Create a new PersonalizationScript and upload corresponding binar...",
        "description" : "Create a new PersonalizationScript and upload corresponding binary data.",
        "operationId" : "createPersoScriptAndUploadBinary",
        "requestBody" : {
          "$ref" : "#/components/requestBodies/binaryPersoScript"
        },
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/PersonalizationScript"
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1011, 1012, 1013, 1014",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1011,
                  "errorMessage" : "Upload failed: missing file."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/personalization-scripts/{personalizationScriptId}" : {
      "get" : {
        "tags" : [ "/personalization-scripts" ],
        "summary" : "Get details of a certain PersonalizationScript.",
        "description" : "Get details of a certain PersonalizationScript.",
        "operationId" : "getPersoScript",
        "parameters" : [ {
          "name" : "personalizationScriptId",
          "in" : "path",
          "description" : "identifier of the referred PersonalizationScript",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "5bd3cb36-3688-e41b-45b4-24abb956e2c5"
          }
        } ],
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/PersonalizationScript"
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1009,
                  "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      },
      "put" : {
        "tags" : [ "/personalization-scripts" ],
        "summary" : "Update details and overwrite binary data of an existing Personali...",
        "description" : "Update details and overwrite binary data of an existing PersonalizationScript.",
        "operationId" : "modifyPersoScriptAndOverwriteBinary",
        "parameters" : [ {
          "name" : "personalizationScriptId",
          "in" : "path",
          "description" : "identifier of the referred PersonalizationScript",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "5bd3cb36-3688-e41b-45b4-24abb956e2c5"
          }
        } ],
        "requestBody" : {
          "$ref" : "#/components/requestBodies/binaryPersoScript"
        },
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/PersonalizationScript"
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1009,
                  "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      },
      "delete" : {
        "tags" : [ "/personalization-scripts" ],
        "summary" : "Delete a certain PersonalizationScript. All data, including binar...",
        "description" : "Delete a certain PersonalizationScript. All data, including binary data, is deleted. Deletion SHALL only be possible if the PersonalizationScript is not referenced in any ApplicationConfig and thus is not in use anywhere.",
        "operationId" : "deletePersoScript",
        "parameters" : [ {
          "name" : "personalizationScriptId",
          "in" : "path",
          "description" : "identifier of the referred PersonalizationScript",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "5bd3cb36-3688-e41b-45b4-24abb956e2c5"
          }
        } ],
        "responses" : {
          "204" : {
            "description" : "item deleted sucessfully"
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009, 1010",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1010,
                  "errorMessage" : "Delete failed: <<entityName>> is referenced in <<entityNameWhereUsed>>."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/personalization-scripts/{personalizationScriptId}/application-configs" : {
      "get" : {
        "tags" : [ "/personalization-scripts" ],
        "summary" : "List all ApplicationConfigs that use a certain PersonalizationScript.",
        "description" : "List all ApplicationConfigs that use a certain PersonalizationScript.",
        "operationId" : "listScriptRelatedAppConfigs",
        "parameters" : [ {
          "name" : "personalizationScriptId",
          "in" : "path",
          "description" : "identifier of the referred PersonalizationScript",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "5bd3cb36-3688-e41b-45b4-24abb956e2c5"
          }
        } ],
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "type" : "array",
                  "items" : {
                    "$ref" : "#/components/schemas/ApplicationConfig"
                  }
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1009,
                  "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/personalization-scripts/{personalizationScriptId}/binary" : {
      "get" : {
        "tags" : [ "/personalization-scripts" ],
        "summary" : "Get binary data of a certain PersonalizationScript.",
        "description" : "Get binary data of a certain PersonalizationScript.",
        "operationId" : "getScriptBinary",
        "parameters" : [ {
          "name" : "personalizationScriptId",
          "in" : "path",
          "description" : "identifier of the referred PersonalizationScript",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "5bd3cb36-3688-e41b-45b4-24abb956e2c5"
          }
        } ],
        "responses" : {
          "200" : {
            "description" : "Ok",
            "headers" : {
              "Content-Disposition" : {
                "style" : "simple",
                "explode" : false,
                "schema" : {
                  "type" : "string",
                  "example" : "attachment; filename=\"filename.pers\""
                }
              }
            },
            "content" : {
              "application/octet-data" : {
                "schema" : {
                  "type" : "string",
                  "description" : "containing actual pers-binary",
                  "format" : "binary"
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1009,
                  "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/personalization-scripts/{personalizationScriptId}/flavors" : {
      "get" : {
        "tags" : [ "/personalization-scripts" ],
        "summary" : "List all Flavors that use a certain PersonalizationScript.",
        "description" : "List all Flavors that use a certain PersonalizationScript.",
        "operationId" : "listScriptRelatedFlavors",
        "parameters" : [ {
          "name" : "personalizationScriptId",
          "in" : "path",
          "description" : "identifier of the referred PersonalizationScript",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "5bd3cb36-3688-e41b-45b4-24abb956e2c5"
          }
        } ],
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "type" : "array",
                  "items" : {
                    "$ref" : "#/components/schemas/Flavor"
                  }
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1009,
                  "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/personalization-scripts/{personalizationScriptId}/services" : {
      "get" : {
        "tags" : [ "/personalization-scripts" ],
        "summary" : "List all Services that use a certain PersonalizationScript.",
        "description" : "List all Services that use a certain PersonalizationScript.",
        "operationId" : "listScriptRelatedServices",
        "parameters" : [ {
          "name" : "personalizationScriptId",
          "in" : "path",
          "description" : "identifier of the referred PersonalizationScript",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "5bd3cb36-3688-e41b-45b4-24abb956e2c5"
          }
        } ],
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "type" : "array",
                  "items" : {
                    "$ref" : "#/components/schemas/Service"
                  }
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1009,
                  "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/certificates" : {
      "get" : {
        "tags" : [ "/certificates" ],
        "summary" : "List all Certificates of the authenticated ServiceProvider.",
        "description" : "List all Certificates of the authenticated ServiceProvider.",
        "operationId" : "listCerts",
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "type" : "array",
                  "items" : {
                    "$ref" : "#/components/schemas/Certificate"
                  }
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - returned error category: 1002",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1002,
                  "errorMessage" : "Invalid: request body not allowed."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      },
      "post" : {
        "tags" : [ "/certificates" ],
        "summary" : "Create a new Certificate and upload corresponding binary data.",
        "description" : "Create a new Certificate and upload corresponding binary data.",
        "operationId" : "createCertAndUploadBinary",
        "requestBody" : {
          "$ref" : "#/components/requestBodies/binaryCertificate"
        },
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/Certificate"
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1011, 1012, 1013, 1014",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1011,
                  "errorMessage" : "Upload failed: missing file."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/certificates/{certificateId}" : {
      "get" : {
        "tags" : [ "/certificates" ],
        "summary" : "Get details of a certain Certificate.",
        "description" : "Get details of a certain Certificate.",
        "operationId" : "getCert",
        "parameters" : [ {
          "name" : "certificateId",
          "in" : "path",
          "description" : "identifier of the referred Certificate",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "ffe6404d-0589-e66c-f837-3e89cfe3d19a"
          }
        } ],
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/Certificate"
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1009,
                  "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      },
      "put" : {
        "tags" : [ "/certificates" ],
        "summary" : "Update details and overwrite binary data of an existing Certificate.",
        "description" : "Update details and overwrite binary data of an existing Certificate.",
        "operationId" : "modifyCertAndOverwriteBinary",
        "parameters" : [ {
          "name" : "certificateId",
          "in" : "path",
          "description" : "identifier of the referred Certificate",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "ffe6404d-0589-e66c-f837-3e89cfe3d19a"
          }
        } ],
        "requestBody" : {
          "$ref" : "#/components/requestBodies/binaryCertificate"
        },
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/Certificate"
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1009,
                  "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      },
      "delete" : {
        "tags" : [ "/certificates" ],
        "summary" : "Delete a certain Certificate. All data, including binary data, is...",
        "description" : "Delete a certain Certificate. All data, including binary data, is deleted. Deletion SHALL only be possible if the Certficate is not referenced in any ApplicationConfig or SposConfig and thus is not in use anywhere.",
        "operationId" : "deleteCert",
        "parameters" : [ {
          "name" : "certificateId",
          "in" : "path",
          "description" : "identifier of the referred Certificate",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "ffe6404d-0589-e66c-f837-3e89cfe3d19a"
          }
        } ],
        "responses" : {
          "204" : {
            "description" : "item deleted sucessfully"
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009, 1010",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1010,
                  "errorMessage" : "Delete failed: <<entityName>> is referenced in <<entityNameWhereUsed>>."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/certificates/{certificateId}/application-configs" : {
      "get" : {
        "tags" : [ "/certificates" ],
        "summary" : "List all ApplicationConfigs that use a certain Certificate.",
        "description" : "List all ApplicationConfigs that use a certain Certificate.",
        "operationId" : "listCertRelatedAppConfigs",
        "parameters" : [ {
          "name" : "certificateId",
          "in" : "path",
          "description" : "identifier of the referred Certificate",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "ffe6404d-0589-e66c-f837-3e89cfe3d19a"
          }
        } ],
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "type" : "array",
                  "items" : {
                    "$ref" : "#/components/schemas/ApplicationConfig"
                  }
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1009,
                  "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/certificates/{certificateId}/binary" : {
      "get" : {
        "tags" : [ "/certificates" ],
        "summary" : "Get binary data of a certain Certificate.",
        "description" : "Get binary data of a certain Certificate.",
        "operationId" : "getCertBinary",
        "parameters" : [ {
          "name" : "certificateId",
          "in" : "path",
          "description" : "identifier of the referred Certificate",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "ffe6404d-0589-e66c-f837-3e89cfe3d19a"
          }
        } ],
        "responses" : {
          "200" : {
            "description" : "Ok",
            "headers" : {
              "Content-Disposition" : {
                "style" : "simple",
                "explode" : false,
                "schema" : {
                  "type" : "string",
                  "example" : "attachment; filename=\"filename.cert\""
                }
              }
            },
            "content" : {
              "application/octet-data" : {
                "schema" : {
                  "type" : "string",
                  "description" : "containing actual cert-binary",
                  "format" : "binary"
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1009,
                  "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/certificates/{certificateId}/flavors" : {
      "get" : {
        "tags" : [ "/certificates" ],
        "summary" : "List all Flavors that use a certain Certificate.",
        "description" : "List all Flavors that use a certain Certificate.",
        "operationId" : "listCertRelatedFlavors",
        "parameters" : [ {
          "name" : "certificateId",
          "in" : "path",
          "description" : "identifier of the referred Certificate",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "ffe6404d-0589-e66c-f837-3e89cfe3d19a"
          }
        } ],
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "type" : "array",
                  "items" : {
                    "$ref" : "#/components/schemas/Flavor"
                  }
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1009,
                  "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/certificates/{certificateId}/services" : {
      "get" : {
        "tags" : [ "/certificates" ],
        "summary" : "List all Services that use a certain Certificate.",
        "description" : "List all Services that use a certain Certificate.",
        "operationId" : "listCertRelatedServices",
        "parameters" : [ {
          "name" : "certificateId",
          "in" : "path",
          "description" : "identifier of the referred Certificate",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "ffe6404d-0589-e66c-f837-3e89cfe3d19a"
          }
        } ],
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "type" : "array",
                  "items" : {
                    "$ref" : "#/components/schemas/Service"
                  }
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1009,
                  "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/certificates/{certificateId}/spos-configs" : {
      "get" : {
        "tags" : [ "/certificates" ],
        "summary" : "List all SposConfigs that use a certain Certificate.",
        "description" : "List all SposConfigs that use a certain Certificate.",
        "operationId" : "listCertRelatedSposConfigs",
        "parameters" : [ {
          "name" : "certificateId",
          "in" : "path",
          "description" : "identifier of the referred Certificate",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "ffe6404d-0589-e66c-f837-3e89cfe3d19a"
          }
        } ],
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "type" : "array",
                  "items" : {
                    "$ref" : "#/components/schemas/SposConfig"
                  }
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1009,
                  "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/spos-configs" : {
      "get" : {
        "tags" : [ "/spos-configs" ],
        "summary" : "List all SposConfigs of the authenticated ServiceProvider.",
        "description" : "List all SposConfigs of the authenticated ServiceProvider.",
        "operationId" : "listSposConfigs",
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "type" : "array",
                  "items" : {
                    "$ref" : "#/components/schemas/SposConfig"
                  }
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - returned error category: 1002",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1002,
                  "errorMessage" : "Invalid: request body not allowed."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      },
      "post" : {
        "tags" : [ "/spos-configs" ],
        "summary" : "Create a new SposConfig and set all corresponding details.",
        "description" : "Create a new SposConfig and set all corresponding details.",
        "operationId" : "createSposConfig",
        "requestBody" : {
          "content" : {
            "application/json" : {
              "schema" : {
                "$ref" : "#/components/schemas/SposConfig"
              },
              "example" : {
                "url" : "/relative/uri/to/resource",
                "certificateId" : "652f7175-d33a-0616-cf61-0451f2587361"
              }
            }
          },
          "required" : true
        },
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/SposConfig"
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1003, 1004, 1007, 1008, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1003,
                  "errorMessage" : "Create failed: attribute <<attributeName>> not allowed for POST. It is automatically assigned when created."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/spos-configs/{sposConfigId}" : {
      "get" : {
        "tags" : [ "/spos-configs" ],
        "summary" : "Get details of a certain SposConfig.",
        "description" : "Get details of a certain SposConfig.",
        "operationId" : "getSposConfig",
        "parameters" : [ {
          "name" : "sposConfigId",
          "in" : "path",
          "description" : "identifier of the referred SposConfig",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "f071b74c-ea66-b415-9a66-4ba06c637d13"
          }
        } ],
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/SposConfig"
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1009,
                  "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      },
      "put" : {
        "tags" : [ "/spos-configs" ],
        "summary" : "Update details of an existing SposConfig.",
        "description" : "Update details of an existing SposConfig.",
        "operationId" : "modifySposConfig",
        "parameters" : [ {
          "name" : "sposConfigId",
          "in" : "path",
          "description" : "identifier of the referred SposConfig",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "f071b74c-ea66-b415-9a66-4ba06c637d13"
          }
        } ],
        "requestBody" : {
          "content" : {
            "application/json" : {
              "schema" : {
                "$ref" : "#/components/schemas/SposConfig"
              },
              "example" : {
                "url" : "/relative/uri/to/resource",
                "certificateId" : "652f7175-d33a-0616-cf61-0451f2587361"
              }
            }
          },
          "required" : true
        },
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/SposConfig"
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1005, 1006, 1007, 1008, 1009",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1005,
                  "errorMessage" : "Modify failed: attribute <<attributeName>> not allowed for PUT. Attribute cannot be modified after creation."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      },
      "delete" : {
        "tags" : [ "/spos-configs" ],
        "summary" : "Delete a certain SposConfig. All data is deleted. Deletion SHALL ...",
        "description" : "Delete a certain SposConfig. All data is deleted. Deletion SHALL only be possible if the SposConfig is not referenced in any Service and thus is not in use anywhere.",
        "operationId" : "deleteSposConfig",
        "parameters" : [ {
          "name" : "sposConfigId",
          "in" : "path",
          "description" : "identifier of the referred SposConfig",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "f071b74c-ea66-b415-9a66-4ba06c637d13"
          }
        } ],
        "responses" : {
          "204" : {
            "description" : "item deleted sucessfully"
          },
          "400" : {
            "description" : "Bad Request - possible error categories: 1002, 1009, 1010",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1010,
                  "errorMessage" : "Delete failed: <<entityName>> is referenced in <<entityNameWhereUsed>>."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    },
    "/spos-configs/{sposConfigId}/services" : {
      "get" : {
        "tags" : [ "/spos-configs" ],
        "summary" : "List all Services that use a certain SposConfig.",
        "description" : "List all Services that use a certain SposConfig.",
        "operationId" : "listSposConfigRelatedServices",
        "parameters" : [ {
          "name" : "sposConfigId",
          "in" : "path",
          "description" : "identifier of the referred SposConfig",
          "required" : true,
          "style" : "simple",
          "explode" : false,
          "schema" : {
            "maxLength" : 36,
            "minLength" : 36,
            "type" : "string",
            "format" : "uuid",
            "example" : "f071b74c-ea66-b415-9a66-4ba06c637d13"
          }
        } ],
        "responses" : {
          "200" : {
            "description" : "Ok",
            "content" : {
              "application/json" : {
                "schema" : {
                  "type" : "array",
                  "items" : {
                    "$ref" : "#/components/schemas/Service"
                  }
                }
              }
            }
          },
          "400" : {
            "description" : "Bad Request - returned error category: 1002",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1002,
                  "errorMessage" : "Invalid: request body not allowed."
                }
              }
            }
          },
          "401" : {
            "description" : "Unauthorized - returned error category: 1000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 1000,
                  "errorMessage" : "Not authenticated"
                }
              }
            }
          },
          "500" : {
            "description" : "Internal Server Error - possible error categories: >= 2000",
            "content" : {
              "application/json" : {
                "schema" : {
                  "$ref" : "#/components/schemas/GeneralError"
                },
                "example" : {
                  "errorCategory" : 2000,
                  "errorMessage" : "Internal server error: Sample error reason"
                }
              }
            }
          }
        },
        "security" : [ {
          "authToken" : [ ]
        } ]
      }
    }
  },
  "components" : {
    "schemas" : {
      "auth-Token" : {
        "type" : "string",
        "description" : "Short-term bearer token, that is used to access Backend-API functions.",
        "example" : "a cryptographic token, transmitted as part of the request header"
      },
      "ServiceProvider" : {
        "required" : [ "name" ],
        "type" : "object",
        "properties" : {
          "id" : {
            "type" : "string",
            "description" : "Unique identification of the SP.",
            "format" : "uuid",
            "readOnly" : true,
            "example" : "6c4a3aa8-5240-ad98-4673-a820be2df3b0"
          },
          "name" : {
            "maxLength" : 255,
            "type" : "string",
            "description" : "Name of the SP.",
            "example" : "nameOfTheSp"
          }
        },
        "description" : "The top-level entity of the data model is a ServiceProvider. The ServiceProvider entity of the data model represents the ('real-life') SP, and both terms will be used interchangeable. The access to resources that are associated with a ServiceProvider is always restricted to the users that are associated with that ServiceProvider. A ServiceProvider has one or more Service entities and zero or more SposConfig entities. The SP can check and modify account information via a REST-API with the following attributes:"
      },
      "Service" : {
        "required" : [ "name" ],
        "type" : "object",
        "properties" : {
          "id" : {
            "type" : "string",
            "description" : "Unique identification of the Service.",
            "format" : "uuid",
            "readOnly" : true,
            "example" : "fde02274-914f-b360-c679-74970a9d6cef"
          },
          "name" : {
            "maxLength" : 255,
            "type" : "string",
            "description" : "Name of the Service.",
            "example" : "nameOfTheService"
          },
          "creationDate" : {
            "type" : "string",
            "description" : "A datetime string (creation of Service).",
            "format" : "date-time",
            "readOnly" : true
          },
          "sdAid" : {
            "type" : "string",
            "description" : "AID of the specific security domain that is created for every Service Instance. The AID format follows [ISO/IEC7816-4].",
            "format" : "aid",
            "readOnly" : true,
            "example" : "A00000025128620C1110"
          },
          "accessAuthorizedDeviceApps" : {
            "type" : "array",
            "description" : "List of apps for which an access rule is created when an instance of this Service is activated.",
            "example" : [ "A00000039998960C1111", "A00000086243583C0111", "A00000052220986C0110" ],
            "items" : {
              "type" : "string",
              "format" : "aid"
            }
          },
          "sposConfigId" : {
            "type" : "string",
            "description" : "ID of the SposConfig used for this Service.",
            "format" : "uuid",
            "example" : "de10f784-d526-618f-443f-2a98cb2c9893"
          },
          "spParameters" : {
            "type" : "object",
            "additionalProperties" : {
              "maxLength" : 255,
              "type" : "string"
            },
            "description" : "Key value definitions used as parameters of a Service. Those parameters can be retrieved via TSM-API. The parameters can be overwritten for each Flavor.",
            "example" : {
              "param1" : "Value1 which can be evaluated by the App.",
              "param2" : "Value2 which can be evaluated by the App.",
              "param3" : "Value3 which can be evaluated by the App."
            }
          }
        },
        "description" : "A Service (as an entity of the data model) represents all data needed for the life-cycle management of a secure application. Services are the key elements for the communication between TSM-Backend and TSM-API. A Service may have multiple Versions with multiple Flavors, which in turn may contain different ELFs. A Service is associated with zero to one SposConfigs. A Service has the following attributes:"
      },
      "Version" : {
        "required" : [ "allowedDeployments", "tag" ],
        "type" : "object",
        "properties" : {
          "tag" : {
            "maxLength" : 11,
            "minLength" : 5,
            "pattern" : "^\\d{1,3}.\\d{1,3}.\\d{1,3}$",
            "type" : "string",
            "description" : "Tag of the Version in the format <Major>.<Minor>.<Revision> The tag must be unique for a Service, since tag is used to reference the Version.",
            "format" : "version",
            "readOnly" : true,
            "example" : "3.1.4"
          },
          "allowedDeployments" : {
            "type" : "object",
            "additionalProperties" : {
              "type" : "array",
              "items" : {
                "maxLength" : 255,
                "type" : "string"
              }
            },
            "description" : "Map, which associates Flavors (see 4.1.4.4) to one or multiple SecureComponentProfiles (see 4.1.4.5). By this, Flavors linked to this Version are assigned to concrete hardware platforms as 1-n association. The key of the map contains the FlavorId. The value of the map is a list of SecureComponentProfileIds. Specific FlavorIds and SecureComponentProfileIds can only be used once inside a Version, i.e., inside a Version it is not supported to assign a SecureComponentProfile to multiple Flavors or vice versa."
          }
        },
        "description" : "A Service can be provided in different Versions. Each Version may have multiple Flavors. Each Flavor defines a set of configurations and ELF files to support a certain hardware platform. The matching of a Flavor to specific SCs is managed via the attribute allowedDeployments. This attribute is a map where one or multiple SecureComponentProfiles are assigned to a specific Flavor. A SecureComponentProfile describes the hardware platform(s) a Flavor is supporting. Thus, inside the Version, a SP MUST define which ELF is used for which hardware platform. The SP also MAY add platform specific configurations. A TSM provider MUST ensure that the FlavorIds and SecureComponentProfileIds are unique for a Version. In the same Version it is not supported to assign a SecureComponentProfile to multiple Flavors or vice versa. A TSM provider MUST also perform a compatibility check when the allowedDeployments attribute is modified. Here, a TSM provider SHALL compare the ELF files with the assigned SecureComponentProfiles, e.g. to check for JavaCard version mismatch or missing CSP support. Such a compatibility check might also be needed when an ELF or a Flavor is modified. The Version is mutable, thus it is allowed to modify a Version when it is already deployed on a device. With this, the SP can assign new SecureComponentProfiles to an existing Version to increase the amount of devices supported by this Version. The SP can also remove SecureComponentProfiles from an existing Version, e.g., in case of a security incident. A Version has the following attributes:"
      },
      "Flavor" : {
        "type" : "object",
        "properties" : {
          "id" : {
            "type" : "string",
            "description" : "Unique identification of the Flavor. The id shall be used to check the necessity of applet reinstallation during the Version update process, for use cases when the same Flavor is used for different Versions.",
            "format" : "uuid",
            "readOnly" : true,
            "example" : "167f43e0-2ada-d0d0-ba18-b23fd6accd18"
          },
          "name" : {
            "maxLength" : 255,
            "type" : "string",
            "description" : "Name of this Flavor.",
            "example" : "nameOfThisFlavor"
          },
          "description" : {
            "maxLength" : 255,
            "type" : "string",
            "description" : "Additional description for this Flavor.",
            "example" : "Additional description for this Flavor."
          },
          "creationDate" : {
            "type" : "string",
            "description" : "A datetime string (creation of Flavor).",
            "format" : "date-time",
            "readOnly" : true
          },
          "published" : {
            "type" : "boolean",
            "description" : "A Flavor can only be used for deployment if it is published. Once published, modification of the following attributes is no longer possible -> executableLoadFileIds -> applicationInstantation Configs Default value is false. The value can be changed to true via the interface method Publish Flavor (see Section 4.1.6.4.15). Once published (value set to true), a Flavor cannot be reversed to an unpublished state again.",
            "readOnly" : true,
            "default" : false
          },
          "executableLoadFileIds" : {
            "type" : "array",
            "description" : "List of IDs of ELFs used by this Flavor. Modifications are only possible, as long as the Flavor is not yet published.",
            "example" : [ "bb5c8384-f856-ca00-2b52-bcf9f45e1f39", "39fb1716-4a34-87ab-18be-8ee81e7f2d67", "bb451440-fdc1-1983-43f2-df17104a4715" ],
            "items" : {
              "type" : "string",
              "format" : "uuid"
            }
          },
          "applicationInstantiationConfigs" : {
            "type" : "array",
            "description" : "List to link and prioritize EMs and ApplicationConfigs. Modifications are only possible, as long as the Flavor is not yet published.",
            "items" : {
              "$ref" : "#/components/schemas/ApplicationInstantiationConfig"
            }
          },
          "spParameters" : {
            "type" : "object",
            "additionalProperties" : {
              "maxLength" : 255,
              "type" : "string"
            },
            "description" : "Key value definitions used as parameters of a service. Those parameters can be retrieved via TSM-API. For the parameters returned by TSM-API the key value pairs are combined with key values pairs of spParameters contained in the Service definition. For pairs with identical keys, the key value pairs of the given flavor take presence over the corresponding pairs contained in spParameters of the Service definition..",
            "example" : {
              "param1" : "Value1 which can be evaluated by the App.",
              "param2" : "Value2 which can be evaluated by the App.",
              "param3" : "Value3 which can be evaluated by the App."
            }
          },
          "featureConfig" : {
            "$ref" : "#/components/schemas/FeatureConfig"
          },
          "contextSpecificAttributes" : {
            "type" : "object",
            "additionalProperties" : {
              "maxLength" : 255,
              "type" : "string"
            },
            "description" : "Additional context specific configuration settings (e.g. platform specific CSP patch level). Possible options are defined bilateral between SP and TSMS provider.",
            "example" : {
              "param1" : "Value1 which can be evaluated by the App.",
              "param2" : "Value2 which can be evaluated by the App.",
              "param3" : "Value3 which can be evaluated by the App."
            }
          }
        },
        "description" : "Services, respectively Versions, can be provided in different Flavors to solve interoperability problems when provisioning Services to different SC platforms. Simply speaking, a Flavor is a certain variant of a Service. A Flavor consists of zero or more ExecutableLoadFile entities, zero or more ApplicationInstantiationConfigs, and exactly one FeatureConfig entity. Flavors need to be published before they can be used for installation. After publishing a Flavor, certain data attributes of the Flavor cannot be modified anymore. The purpose is to avoid the problem that Flavor modifications done on a Flavor which is already installed might lead to inconsistencies on the handset. The allocation of a Flavor to one or multiple SecureComponentProfiles is done via the allowedDeployments attribute of the parent Version of each Flavor. A Flavor has the following attributes:"
      },
      "SecureComponentProfile" : {
        "required" : [ "certifications", "csp", "gpApiVersions", "gpSpecVersions", "hardwarePlatform", "javaCardFeatures", "javaCardVersion", "name", "os", "osVersion", "scType" ],
        "type" : "object",
        "properties" : {
          "id" : {
            "type" : "string",
            "description" : "Unique identification of the Secure Component Profile assigned automatically by TSMS.",
            "format" : "uuid",
            "readOnly" : true,
            "example" : "fd4aad1f-50f8-1534-aeab-652bafa65604"
          },
          "name" : {
            "maxLength" : 255,
            "type" : "string",
            "description" : "Name of the SecureComponentProfile.",
            "readOnly" : true,
            "example" : "nameOfTheSecurecomponentprofile"
          },
          "scType" : {
            "maximum" : 4,
            "minimum" : 1,
            "type" : "integer",
            "description" : "Secure component type. One of -> 1 EMBEDDED_SE -> 2 EMBEDDED_UICC -> 3 REMOVABLE_EUICC -> 4 UICC",
            "readOnly" : true,
            "example" : 1
          },
          "hardwarePlatform" : {
            "maxLength" : 255,
            "type" : "string",
            "description" : "Name of hardware platform / chip. Sample values are P62G98, S9FD2EE.",
            "readOnly" : true,
            "example" : "P62G98"
          },
          "os" : {
            "maxLength" : 255,
            "type" : "string",
            "description" : "Secure component operating system name, e.g. GTO, JCOP.",
            "readOnly" : true,
            "example" : "JCOP"
          },
          "osVersion" : {
            "maxLength" : 7,
            "minLength" : 3,
            "pattern" : "^\\d{1,3}.\\d{1,3}$",
            "type" : "string",
            "description" : "Version of operating system with vendor specific encoding. Sample values are 4.7, 3.1.",
            "readOnly" : true,
            "example" : "4.7"
          },
          "javaCardVersion" : {
            "maxLength" : 11,
            "minLength" : 5,
            "pattern" : "^\\d{1,3}.\\d{1,3}.\\d{1,3}$",
            "type" : "string",
            "description" : "JavaCard version. Sample values are 3.0.5, 3.0.4.",
            "format" : "version",
            "readOnly" : true,
            "example" : "3.0.5"
          },
          "javaCardFeatures" : {
            "type" : "object",
            "additionalProperties" : {
              "type" : "array",
              "items" : {
                "maxLength" : 255,
                "type" : "string"
              }
            },
            "description" : "Features provided by the JavaCard. The key contains the name of the feature. The value contains a list of supported algorithm for each feature. Sample keys are -> cypher -> signature -> messageDigest -> randomData -> keyBuilder -> keyAgreement -> checksum -> keyPairAlgRsaOnCardGeneration -> keyPairAlgRsaCrtOnCardGeneration -> keyPairAlgDsaOnCardGeneration -> keyPairAlgEcF2MOnCardGeneration -> keyPairAlgEcFpOnCardGeneration -> aeadCipher",
            "readOnly" : true
          },
          "gpSpecVersions" : {
            "type" : "object",
            "additionalProperties" : {
              "maxLength" : 255,
              "type" : "string"
            },
            "description" : "Global Platform Specification versions. The key contains an identifier for the GP specification document. The value contains the version for each specification. Sample keys are -> card -> contactlessServices -> scp03 -> executableLoadFileUpgrade Sample values are 2.3.1, 2.3, 2.2.1.",
            "readOnly" : true,
            "example" : {
              "card" : "2.3.1",
              "contactlessServices" : "2.3"
            }
          },
          "gpApiVersions" : {
            "type" : "object",
            "additionalProperties" : {
              "maxLength" : 255,
              "type" : "string"
            },
            "description" : "GlobalPlatform API versions. The key contains an identifier for the GP API. The value contains the version for each API. Sample keys are -> card -> contactless -> elfUpgrade Sample values are 1.7, 1.6.",
            "readOnly" : true,
            "example" : {
              "card" : "1.7",
              "contactless" : "1.6"
            }
          },
          "csp" : {
            "type" : "object",
            "additionalProperties" : {
              "maxLength" : 255,
              "type" : "string"
            },
            "description" : "Supported CSP. Empty when no CSP is available. Key contains an identifier for additional information about the CSP. Value contains the additional CSP information. Sample keys are -> apiVersion -> vendor",
            "readOnly" : true,
            "example" : {
              "apiVersion" : "1.0",
              "vendor" : "nxp"
            }
          },
          "certifications" : {
            "type" : "object",
            "additionalProperties" : {
              "maxLength" : 255,
              "type" : "string"
            },
            "description" : "Platform certification level. The key contains the identifier of the certification. The value contains the link to the letter of approval. Sample keys are -> BSI-CC-PP-0084-2014 -> BSI-CC-PP-0089-2015 -> BSI-CC-PP-0099-2017 -> BSI-CC-PP-0100-2018 -> BSI-CC-PP-0104-2019 -> BSI-CC-PP-0117-2022",
            "readOnly" : true,
            "example" : {
              "BSI-CC-PP-0084-2014" : "link/to/letter/of/approval/1",
              "BSI-CC-PP-0100-2018" : "link/to/letter/of/approval/2"
            }
          }
        },
        "description" : "A SecureComponentProfile describes a secure component by its properties like JavaCard version, operating system name and version, chip identifier etc. The SP can retrieve this list via the TSM-Backend REST-API to determine supported hardware platforms. With this information, the SP can prepare the necessary ELF files and configure a corresponding Flavor. Finally, the SP assigns specific SecureComponentProfiles to this Flavor to control on which platforms it shall be deployed. This is done via the allowedDeployments attribute of the Version (see Section 4.1.4.3.) A SecureComponentProfile has the following attributes:"
      },
      "FeatureConfig" : {
        "type" : "object",
        "properties" : {
          "cspFull" : {
            "type" : "boolean",
            "description" : "True if the SC is required to support full CSP mode, false otherwise. Default value is false.",
            "default" : false
          },
          "genericOptions" : {
            "type" : "object",
            "additionalProperties" : {
              "type" : "boolean"
            },
            "description" : "Possibility to configure further feature options (e.g. key-agreement-algorithm, message-digest). Default value is an empty list.",
            "default" : { }
          }
        },
        "description" : "The FeatureConfig is part of a Flavor. It is used to indicate the use of features supported by a SC which is associated to the Flavor as part of the allowedDeployments attribute of a Version applied for deployment. The FeatureConfig data type is only used as a complex type inside Flavor and is not directly referenced in any API methods. Currently, it only has one attribute."
      },
      "ApplicationInstantiationConfig" : {
        "required" : [ "applicationConfigId", "executableModuleId" ],
        "type" : "object",
        "properties" : {
          "priority" : {
            "maximum" : 255,
            "minimum" : 1,
            "type" : "integer",
            "description" : "Priority, which specifies the order in which an application should be instantiated. Must be in the range from 1 to 255. A lower value means a higher priority. Default value is 255."
          },
          "executableModuleId" : {
            "type" : "string",
            "description" : "ID of the EM the referenced ApplicationConfig shall be applied to.",
            "format" : "uuid",
            "example" : "96f3baa5-d50c-84e4-b285-07b679aa6953"
          },
          "applicationConfigId" : {
            "type" : "string",
            "description" : "ID of the ApplicationConfig that shall be applied to the referenced EM.",
            "format" : "uuid",
            "example" : "69c1eede-6767-ddbc-6c84-3903126e51b4"
          }
        },
        "description" : "The ApplicationInstantiationConfig contains the link between EM and the ApplicationConfig for a certain Flavor. A lower value of priority indicates that an ApplicationInstantiationConfig shall be applied before an ApplicationInstantiationConfig with a higher value of priority. If multiple ApplicationInstantiationConfigs within the same Flavor have the same priority value, the TSM will choose which one will be applied first. The ApplicationInstantiationConfig is only used as complex type inside Flavor and is not directly referenced in any API methods. It has the following attributes:"
      },
      "ExecutableLoadFile" : {
        "type" : "object",
        "properties" : {
          "id" : {
            "type" : "string",
            "description" : "Unique identification of the ELF.",
            "format" : "uuid",
            "readOnly" : true,
            "example" : "a38d4f8a-a4d5-d5c9-b134-0657c74a9853"
          },
          "aid" : {
            "type" : "string",
            "description" : "Package-ID of this ELF.",
            "format" : "aid",
            "readOnly" : true,
            "example" : "A00000030027697C0110"
          },
          "fileName" : {
            "maxLength" : 255,
            "type" : "string",
            "description" : "Name of this ELF.",
            "example" : "nameOfThisElf"
          },
          "type" : {
            "maxLength" : 255,
            "type" : "string",
            "description" : "Type of this ELF. Currently, only CAP is supported.",
            "readOnly" : true
          },
          "creationDate" : {
            "type" : "string",
            "description" : "A datetime string (creation of ELF)",
            "format" : "date-time",
            "readOnly" : true
          },
          "uploadDate" : {
            "type" : "string",
            "description" : "A datetime string (upload of ELF binary). Binary of an ELF can be replaced only as long as the ELF is not linked to a published Flavor.",
            "format" : "date-time",
            "readOnly" : true
          }
        },
        "description" : "An ExecutableLoadFile (ELF) is an executable binary file that can be loaded onto a Secure Component. In SmartCard terminology, the ELF is a container of executable code on a secure component [GPC_SPE_034]. ELFs are essential components of a Flavor used by a Version of a Service. ELFs are uploaded by the SP and may be used in different Flavors. An ELF may contain zero or more ExecutableModule entities. The specific type of an ELF is determined at upload time. If the ELF is a CAP, the ELF AID is automatically extracted from the CAP. An ELF has the following attributes:"
      },
      "CAP" : {
        "type" : "object",
        "properties" : {
          "packageName" : {
            "maxLength" : 255,
            "type" : "string",
            "description" : "Name of the package of the CAP.",
            "readOnly" : true,
            "example" : "nameOfThePackageOfTheCap"
          },
          "importedPackages" : {
            "type" : "array",
            "description" : "List of imported package AIDs used by the EM of this CAP.",
            "readOnly" : true,
            "items" : {
              "maxLength" : 255,
              "type" : "string"
            }
          },
          "packageVersion" : {
            "maxLength" : 7,
            "minLength" : 3,
            "pattern" : "^\\d{1,3}.\\d{1,3}$",
            "type" : "string",
            "description" : "Version of the package ('major.minor').",
            "format" : "version",
            "readOnly" : true,
            "example" : "1.7"
          },
          "technicalRequirements" : {
            "$ref" : "#/components/schemas/TechnicalRequirements"
          }
        },
        "description" : "A CAP is a Java Card realization of an ELF. It is derived from ExecutableLoadFile and adds the following attributes:"
      },
      "TechnicalRequirements" : {
        "type" : "object",
        "properties" : {
          "javaCardVersion" : {
            "maxLength" : 11,
            "minLength" : 5,
            "pattern" : "^\\d{1,3}.\\d{1,3}.\\d{1,3}$",
            "type" : "string",
            "description" : "Version of Java Card required by the CAP ('major.minor.patch').",
            "format" : "version",
            "readOnly" : true,
            "example" : "2.3.1"
          },
          "gpApiVersion" : {
            "maxLength" : 7,
            "minLength" : 3,
            "pattern" : "^\\d{1,3}.\\d{1,3}$",
            "type" : "string",
            "description" : "Version of GlobalPlatform API required by the CAP ('major.minor.patch').",
            "format" : "version",
            "readOnly" : true,
            "example" : "5.12"
          }
        },
        "description" : "The TechnicalRequirements data type is used to define technical requirements needed to execute a CAP. Those requirements are detected automatically when uploading the binary file and are checked against the SecureComponentProfiles when modifying the allowedDeployments of a Flavor. The TechnicalRequirements data type is only used as a complex type inside CAP and is not directly referenced in any API methods. It has the following attributes:"
      },
      "ExecutableModule" : {
        "type" : "object",
        "properties" : {
          "id" : {
            "type" : "string",
            "description" : "Unique identification of the EM.",
            "format" : "uuid",
            "readOnly" : true,
            "example" : "26dffd3f-59fd-80b3-bc31-29dca2795831"
          },
          "aid" : {
            "type" : "string",
            "description" : "Application identifier of this EM. The AID format follows [ISO/IEC7816-4].",
            "format" : "aid",
            "readOnly" : true,
            "example" : "A00000065553856C1001"
          }
        },
        "description" : "ExecutableModules (EMs) are contained in ELFs. Thus, an EM is always bound to an ELF. A specific example of an EM is a Java Card Applet. A Java Card Applet is a specific class which extends javacard.framework.Applet and is part of a CAP file, which is a technology-specific type of an ELF in this context. An EM has the following attributes:"
      },
      "ApplicationConfig" : {
        "required" : [ "installConfig", "instanceAid" ],
        "type" : "object",
        "properties" : {
          "id" : {
            "type" : "string",
            "description" : "Unique identification of the ApplicationConfig.",
            "format" : "uuid",
            "readOnly" : true,
            "example" : "47db1f00-d894-af9a-a27b-1303d61fa3f4"
          },
          "instanceAid" : {
            "type" : "string",
            "description" : "AID of the running application instance that shall be created from this ApplicationConfig. This AID is also the AID that is used for selecting a selectable application on the SC. The AID format follows [ISO/IEC7816-4].",
            "format" : "aid",
            "example" : "A00000037797423C1100"
          },
          "name" : {
            "maxLength" : 255,
            "type" : "string",
            "description" : "Name of this ApplicationConfig.",
            "example" : "nameOfThisApplicationconfig"
          },
          "description" : {
            "maxLength" : 255,
            "type" : "string",
            "description" : "Description of this ApplicationConfig.",
            "example" : "Description of this ApplicationConfig."
          },
          "installConfig" : {
            "$ref" : "#/components/schemas/InstallConfig"
          },
          "activationConfig" : {
            "$ref" : "#/components/schemas/ActivationConfig"
          },
          "personalizationConfig" : {
            "$ref" : "#/components/schemas/PersonalizationConfig"
          }
        },
        "description" : "An ApplicationConfig consists of parameters, certificates and other properties needed for provisioning applications. All configuration options defined here are applied to the secure component during deploy or update service commands triggered with the TSM-API. The ApplicationConfig itself is not dependent on a specific EM. In order to link it to an EM, the ApplicationConfig is referenced in an ApplicationInstantiationConfig within a Flavor by a mapping of available EMs and corresponding ApplicationConfigs. The same ApplicationConfigs can be used for EMs in different Flavors. An ApplicationConfig has the following attributes:"
      },
      "InstallConfig" : {
        "type" : "object",
        "properties" : {
          "applicationSpecificInstallParameter" : {
            "maxLength" : 255,
            "type" : "string",
            "description" : "List of application specific parameters needed for installation. If omitted, empty application specific parameters will be used. Format <TLV-Structures>.",
            "format" : "tlv",
            "example" : "0f 09 e6 ea e9 06 8d 89 19 a4 8a"
          },
          "privileges" : {
            "type" : "array",
            "description" : "List of required privileges for an application instance. Subset of -> 'CVMManagement' -> 'ContactlessSelfActivation' -> 'GlobalService' -> 'PrivacyTrusted'",
            "items" : {
              "maxLength" : 255,
              "type" : "string"
            }
          }
        },
        "description" : "An InstallConfig is a structure to configure configuration options needed to deploy a Service to lifecycle state Installed. It defines configuration settings which are applied to the applet during deploy or update processes triggered with the TSM-API when using the InstallServiceCommand parameter. The InstallConfig data type is only used as a complex type inside ApplicationConfig and is not directly referenced in any API methods. It has the following attributes:"
      },
      "ActivationConfig" : {
        "type" : "object",
        "properties" : {
          "makeSelectable" : {
            "type" : "boolean",
            "description" : "Flag, whether application instance to be created shall be made selectable. If omitted, default value true will be used.",
            "default" : true
          },
          "accessibleViaApdu" : {
            "type" : "boolean",
            "description" : "Flag, whether the application instance to be created will be accessible via APDU. Can only be applied if makeSelectable is true. If omitted, default value false will be used.",
            "default" : false
          },
          "accessibleViaNfc" : {
            "type" : "boolean",
            "description" : "Flag, whether the application instance to be created will be accessible via NFC. Can only be applied if makeSelectable is true. If omitted, default value false will be used.",
            "default" : false
          }
        },
        "description" : "An ActivationConfig is a structure to configure configuration options needed to deploy a Service to lifecycle state Activated. It defines configuration settings which are applied to the applet during deploy or update processes triggered with the TSM-API when using the ActivateServiceCommand parameter. The ActivationConfig data type is only used as a complex type inside ApplicationConfig and is not directly referenced in any API methods. It has following attributes:"
      },
      "PersonalizationConfig" : {
        "type" : "object",
        "properties" : {
          "certificateId" : {
            "type" : "string",
            "description" : "ID of the Certificate, if needed for a PersonalizationScript.",
            "format" : "uuid",
            "example" : "8fa10eff-19a2-7c4b-1102-2e8b867d3fda"
          },
          "personalizationScriptId" : {
            "type" : "string",
            "description" : "ID of the PersonalizationScript used for personalization.",
            "format" : "uuid",
            "example" : "8339dcd0-b9e1-6b73-b5f0-33793d4e2307"
          },
          "provideAttestationToken" : {
            "type" : "boolean",
            "description" : "Flag, whether an AttestationToken shall be included in the application specific install parameters. If omitted, default value false will be used.",
            "default" : false
          },
          "includeKeyDiversificationData" : {
            "type" : "boolean",
            "description" : "Flag, whether Key Diversification Data shall be included in the Attestation Token. Can only be applied if provideAttestationToken is true. If omitted, default value false will be used.",
            "default" : false
          }
        },
        "description" : "A PersonalizationConfig is a structure to configure configuration options needed to deploy a Service to lifecycle state Personalized. It defines configuration settings which are applied to the applet during deploy or update processes triggered with the TSM-API when using the PersonalizeServiceCommand parameter. The PersonalizationConfig data type is only used as a complex type inside ApplicationConfig and is not directly referenced in any API methods. It has the following attributes:"
      },
      "PersonalizationScript" : {
        "type" : "object",
        "properties" : {
          "id" : {
            "type" : "string",
            "description" : "Unique identification of the Personalization-Script.",
            "format" : "uuid",
            "readOnly" : true,
            "example" : "060dc3ac-71dd-3bae-e00a-a8fe85ceb022"
          },
          "fileName" : {
            "maxLength" : 255,
            "type" : "string",
            "description" : "Name of this PersonalizationScript.",
            "example" : "nameOfThisPersonalizationscript"
          },
          "creationDate" : {
            "type" : "string",
            "description" : "A datetime string (creation of Personalization-Script).",
            "format" : "date-time",
            "readOnly" : true
          },
          "uploadDate" : {
            "type" : "string",
            "description" : "A datetime string (upload of Personalization-Script binary).",
            "format" : "date-time",
            "readOnly" : true
          }
        },
        "description" : "A PersonalizationScript is a script a SP may use to specify installation instructions or request TSM-support for, e.g., the personalization of a secure application during the provisioning process. This interface only provides methods to manage the PersonalizationScripts and link them with Certificates for communication to a SP backend (if required). The content of the PersonalizationScript is currently not in the scope of this TR. A PersonalizationScript has the following attributes:"
      },
      "Certificate" : {
        "type" : "object",
        "properties" : {
          "id" : {
            "type" : "string",
            "description" : "Unique identification of the Certificate.",
            "format" : "uuid",
            "readOnly" : true,
            "example" : "2355d041-c1c6-4ab1-e0d2-a15a41e85351"
          },
          "fileName" : {
            "maxLength" : 255,
            "type" : "string",
            "description" : "Name of the file the Certificate was created from.",
            "example" : "nameOfTheFileTheCertificateWasCreatedFrom"
          },
          "creationDate" : {
            "type" : "string",
            "description" : "A datetime string (creation of Certificate).",
            "format" : "date-time",
            "readOnly" : true
          },
          "uploadDate" : {
            "type" : "string",
            "description" : "A datetime string (upload of Certificate binary).",
            "format" : "date-time",
            "readOnly" : true
          }
        },
        "description" : "A Certificate is used for the communication between TSM and SP Online System and also in PersonalizationScripts for applet provisioning and personalization. A Certificate has the following attributes:"
      },
      "SposConfig" : {
        "required" : [ "certificateId", "url" ],
        "type" : "object",
        "properties" : {
          "id" : {
            "type" : "string",
            "description" : "Unique identification of the SposConfig.",
            "format" : "uuid",
            "readOnly" : true,
            "example" : "f36d5f2e-0950-6e80-6367-fe7e6250a713"
          },
          "url" : {
            "maxLength" : 500,
            "type" : "string",
            "description" : "URL of the SP's Online Service.",
            "format" : "uri",
            "example" : "/relative/uri/to/resource"
          },
          "certificateId" : {
            "type" : "string",
            "description" : "ID of the Certificate that is used for the backend communication.",
            "format" : "uuid",
            "example" : "6cda80a1-efb3-acf3-8b18-14a10ff2ad24"
          }
        },
        "description" : "SposConfig is used to configure communication with the Service Provider Online System. The aim is to enable a service provider to receive process success and process error messages sent by the TSM. A SposConfig has the following attributes:"
      },
      "GeneralError" : {
        "required" : [ "errorCategory", "errorMessage" ],
        "type" : "object",
        "properties" : {
          "errorCategory" : {
            "maximum" : 9999,
            "minimum" : 1000,
            "type" : "integer",
            "description" : "The error type.",
            "readOnly" : true
          },
          "errorMessage" : {
            "maxLength" : 255,
            "type" : "string",
            "description" : "A human-readable error description in English.",
            "readOnly" : true
          }
        },
        "description" : "A GeneralError is used as response object for any REST method call in case the response status code is not 2xx. GeneralError has the following attributes:"
      }
    },
    "responses" : {
      "200Binary_ELF" : {
        "description" : "Ok",
        "headers" : {
          "Content-Disposition" : {
            "style" : "simple",
            "explode" : false,
            "schema" : {
              "type" : "string",
              "example" : "attachment; filename=\"filename.cap\""
            }
          }
        },
        "content" : {
          "application/octet-data" : {
            "schema" : {
              "type" : "string",
              "description" : "containing actual elf-binary",
              "format" : "binary"
            }
          }
        }
      },
      "200Binary_Script" : {
        "description" : "Ok",
        "headers" : {
          "Content-Disposition" : {
            "style" : "simple",
            "explode" : false,
            "schema" : {
              "type" : "string",
              "example" : "attachment; filename=\"filename.pers\""
            }
          }
        },
        "content" : {
          "application/octet-data" : {
            "schema" : {
              "type" : "string",
              "description" : "containing actual pers-binary",
              "format" : "binary"
            }
          }
        }
      },
      "200Binary_Cert" : {
        "description" : "Ok",
        "headers" : {
          "Content-Disposition" : {
            "style" : "simple",
            "explode" : false,
            "schema" : {
              "type" : "string",
              "example" : "attachment; filename=\"filename.cert\""
            }
          }
        },
        "content" : {
          "application/octet-data" : {
            "schema" : {
              "type" : "string",
              "description" : "containing actual cert-binary",
              "format" : "binary"
            }
          }
        }
      },
      "400Error_1002" : {
        "description" : "Bad Request - returned error category: 1002",
        "content" : {
          "application/json" : {
            "schema" : {
              "$ref" : "#/components/schemas/GeneralError"
            },
            "example" : {
              "errorCategory" : 1002,
              "errorMessage" : "Invalid: request body not allowed."
            }
          }
        }
      },
      "400Error_1002_1009" : {
        "description" : "Bad Request - possible error categories: 1002, 1009",
        "content" : {
          "application/json" : {
            "schema" : {
              "$ref" : "#/components/schemas/GeneralError"
            },
            "example" : {
              "errorCategory" : 1009,
              "errorMessage" : "Not existing: <<entityName>> with identifier '<<attributeValue>>' is not existing."
            }
          }
        }
      },
      "400Error_1002_1009_1010" : {
        "description" : "Bad Request - possible error categories: 1002, 1009, 1010",
        "content" : {
          "application/json" : {
            "schema" : {
              "$ref" : "#/components/schemas/GeneralError"
            },
            "example" : {
              "errorCategory" : 1010,
              "errorMessage" : "Delete failed: <<entityName>> is referenced in <<entityNameWhereUsed>>."
            }
          }
        }
      },
      "400Error_1002_1011_1012_1013_1014" : {
        "description" : "Bad Request - possible error categories: 1002, 1011, 1012, 1013, 1014",
        "content" : {
          "application/json" : {
            "schema" : {
              "$ref" : "#/components/schemas/GeneralError"
            },
            "example" : {
              "errorCategory" : 1011,
              "errorMessage" : "Upload failed: missing file."
            }
          }
        }
      },
      "400Error_1003_1004_1007_1008_1009_1011_1012_1013_1014" : {
        "description" : "Bad Request - possible error categories: 1003, 1004, 1007, 1008, 1009, 1011, 1012, 1013, 1014",
        "content" : {
          "application/json" : {
            "schema" : {
              "$ref" : "#/components/schemas/GeneralError"
            },
            "example" : {
              "errorCategory" : 1013,
              "errorMessage" : "Upload failed: invalid file type. Supported file types are <<fileTypeList>>."
            }
          }
        }
      },
      "400Error_1003_1004_1007_1008_1009" : {
        "description" : "Bad Request - possible error categories: 1003, 1004, 1007, 1008, 1009",
        "content" : {
          "application/json" : {
            "schema" : {
              "$ref" : "#/components/schemas/GeneralError"
            },
            "example" : {
              "errorCategory" : 1003,
              "errorMessage" : "Create failed: attribute <<attributeName>> not allowed for POST. It is automatically assigned when created."
            }
          }
        }
      },
      "400Error_1003_1004_1007_1008_1009_1016" : {
        "description" : "Bad Request - possible error categories: 1003, 1004, 1007, 1008, 1009, 1016",
        "content" : {
          "application/json" : {
            "schema" : {
              "$ref" : "#/components/schemas/GeneralError"
            },
            "example" : {
              "errorCategory" : 1004,
              "errorMessage" : "Create failed: attribute <<attributeName>> is missing, but it is mandatory for <<entityName>>."
            }
          }
        }
      },
      "400Error_1005_1006_1007_1008_1009" : {
        "description" : "Bad Request - possible error categories: 1005, 1006, 1007, 1008, 1009",
        "content" : {
          "application/json" : {
            "schema" : {
              "$ref" : "#/components/schemas/GeneralError"
            },
            "example" : {
              "errorCategory" : 1005,
              "errorMessage" : "Modify failed: attribute <<attributeName>> not allowed for PUT. Attribute cannot be modified after creation."
            }
          }
        }
      },
      "400Error_1005_1006_1007_1008_1009_1011_1012_1013_1014_1015_1016" : {
        "description" : "Bad Request - possible error categories: 1005, 1006, 1007, 1008, 1009, 1011, 1012, 1013, 1014, 1015, 1016",
        "content" : {
          "application/json" : {
            "schema" : {
              "$ref" : "#/components/schemas/GeneralError"
            },
            "example" : {
              "errorCategory" : 1007,
              "errorMessage" : "Unknown: ‘<<attributeName>>’ is not a valid attribute."
            }
          }
        }
      },
      "400Error_1005_1006_1007_1008_1009_1015_1016" : {
        "description" : "Bad Request - possible error categories: 1005, 1006, 1007, 1008, 1009, 1015, 1016",
        "content" : {
          "application/json" : {
            "schema" : {
              "$ref" : "#/components/schemas/GeneralError"
            },
            "example" : {
              "errorCategory" : 1015,
              "errorMessage" : "Already Published: <<entityName>> cannot be modified. It is already published via Flavor identifier ‘<<attributeValue>>’."
            }
          }
        }
      },
      "400Error_1005_1006_1007_1008_1009_1016" : {
        "description" : "Bad Request - possible error categories: 1005, 1006, 1007, 1008, 1009, 1016",
        "content" : {
          "application/json" : {
            "schema" : {
              "$ref" : "#/components/schemas/GeneralError"
            },
            "example" : {
              "errorCategory" : 1016,
              "errorMessage" : "Technical constraints failed: minimal <<attributeName>> version not supported by SecureComponentProfile."
            }
          }
        }
      },
      "400Error_1008_1009" : {
        "description" : "Bad Request - possible error categories: 1008, 1009",
        "content" : {
          "application/json" : {
            "schema" : {
              "$ref" : "#/components/schemas/GeneralError"
            },
            "example" : {
              "errorCategory" : 1008,
              "errorMessage" : "Invalid format '<<attributeValue>>' for << attributeName>>. Supported format is <<formatDefinition>>."
            }
          }
        }
      },
      "400Error_1008_1009_1015" : {
        "description" : "Bad Request - possible error categories: 1008, 1009, 1015",
        "content" : {
          "application/json" : {
            "schema" : {
              "$ref" : "#/components/schemas/GeneralError"
            },
            "example" : {
              "errorCategory" : 1008,
              "errorMessage" : "Invalid format '<<attributeValue>>' for << attributeName>>. Supported format is <<formatDefinition>>."
            }
          }
        }
      },
      "400Error_1008_1009_1015_1016" : {
        "description" : "Bad Request - possible error categories: 1008, 1009, 1015, 1016",
        "content" : {
          "application/json" : {
            "schema" : {
              "$ref" : "#/components/schemas/GeneralError"
            },
            "example" : {
              "errorCategory" : 1015,
              "errorMessage" : "Already Published: <<entityName>> cannot be modified. It is already published via Flavor identifier ‘<<attributeValue>>’."
            }
          }
        }
      },
      "400Error_1008_1009_1016" : {
        "description" : "Bad Request - possible error categories: 1008, 1009, 1016",
        "content" : {
          "application/json" : {
            "schema" : {
              "$ref" : "#/components/schemas/GeneralError"
            },
            "example" : {
              "errorCategory" : 1016,
              "errorMessage" : "Technical constraints failed: minimal <<attributeName>> version not supported by SecureComponentProfile."
            }
          }
        }
      },
      "401Error_1000" : {
        "description" : "Unauthorized - returned error category: 1000",
        "content" : {
          "application/json" : {
            "schema" : {
              "$ref" : "#/components/schemas/GeneralError"
            },
            "example" : {
              "errorCategory" : 1000,
              "errorMessage" : "Not authenticated"
            }
          }
        }
      },
      "401Error_1001" : {
        "description" : "Unauthorized - returned error category: 1001",
        "content" : {
          "application/json" : {
            "schema" : {
              "$ref" : "#/components/schemas/GeneralError"
            },
            "example" : {
              "errorCategory" : 1001,
              "errorMessage" : "Authentication failed."
            }
          }
        }
      },
      "403Error_1000" : {
        "description" : "Forbidden - returned error category: 1000",
        "content" : {
          "application/json" : {
            "schema" : {
              "$ref" : "#/components/schemas/GeneralError"
            },
            "example" : {
              "errorCategory" : 1000,
              "errorMessage" : "Not authenticated"
            }
          }
        }
      },
      "500Error_2000" : {
        "description" : "Internal Server Error - possible error categories: >= 2000",
        "content" : {
          "application/json" : {
            "schema" : {
              "$ref" : "#/components/schemas/GeneralError"
            },
            "example" : {
              "errorCategory" : 2000,
              "errorMessage" : "Internal server error: Sample error reason"
            }
          }
        }
      }
    },
    "parameters" : {
      "scpId" : {
        "name" : "scpId",
        "in" : "path",
        "description" : "identifier of the referred Scp",
        "required" : true,
        "style" : "simple",
        "explode" : false,
        "schema" : {
          "maxLength" : 36,
          "minLength" : 36,
          "type" : "string",
          "format" : "uuid",
          "example" : "bc675568-34ac-40b0-abc0-03929b2d5ccd"
        }
      },
      "serviceId" : {
        "name" : "serviceId",
        "in" : "path",
        "description" : "identifier of the referred Service",
        "required" : true,
        "style" : "simple",
        "explode" : false,
        "schema" : {
          "maxLength" : 36,
          "minLength" : 36,
          "type" : "string",
          "format" : "uuid",
          "example" : "e59d3d32-6756-76ac-ffff-feeba10c081a"
        }
      },
      "flavorId" : {
        "name" : "flavorId",
        "in" : "path",
        "description" : "identifier of the referred Flavor",
        "required" : true,
        "style" : "simple",
        "explode" : false,
        "schema" : {
          "maxLength" : 36,
          "minLength" : 36,
          "type" : "string",
          "format" : "uuid",
          "example" : "ff686d37-4674-1456-26fa-c9ed658bb41c"
        }
      },
      "tag" : {
        "name" : "tag",
        "in" : "path",
        "description" : "identifier of the referred Tag",
        "required" : true,
        "style" : "simple",
        "explode" : false,
        "schema" : {
          "maxLength" : 11,
          "minLength" : 5,
          "pattern" : "^\\d{1,3}.\\d{1,3}.\\d{1,3}$",
          "type" : "string",
          "format" : "version",
          "example" : "4.31.005"
        }
      },
      "elfId" : {
        "name" : "elfId",
        "in" : "path",
        "description" : "identifier of the referred Elf",
        "required" : true,
        "style" : "simple",
        "explode" : false,
        "schema" : {
          "maxLength" : 36,
          "minLength" : 36,
          "type" : "string",
          "format" : "uuid",
          "example" : "c73e8ddc-0318-7940-dc7d-ae5bab5ce549"
        }
      },
      "emId" : {
        "name" : "emId",
        "in" : "path",
        "description" : "identifier of the referred Em",
        "required" : true,
        "style" : "simple",
        "explode" : false,
        "schema" : {
          "maxLength" : 36,
          "minLength" : 36,
          "type" : "string",
          "format" : "uuid",
          "example" : "4079f402-4e86-b4b0-0c4f-a21681ece9c8"
        }
      },
      "servideId" : {
        "name" : "servideId",
        "in" : "path",
        "description" : "identifier of the referred Servide",
        "required" : true,
        "style" : "simple",
        "explode" : false,
        "schema" : {
          "maxLength" : 36,
          "minLength" : 36,
          "type" : "string",
          "format" : "uuid",
          "example" : "615c1678-895b-ff21-7c6c-bcd9fed11b84"
        }
      },
      "applicationConfigId" : {
        "name" : "applicationConfigId",
        "in" : "path",
        "description" : "identifier of the referred ApplicationConfig",
        "required" : true,
        "style" : "simple",
        "explode" : false,
        "schema" : {
          "maxLength" : 36,
          "minLength" : 36,
          "type" : "string",
          "format" : "uuid",
          "example" : "a0f59df9-7ee2-161f-9325-46e1ecc0ecae"
        }
      },
      "personalizationScriptId" : {
        "name" : "personalizationScriptId",
        "in" : "path",
        "description" : "identifier of the referred PersonalizationScript",
        "required" : true,
        "style" : "simple",
        "explode" : false,
        "schema" : {
          "maxLength" : 36,
          "minLength" : 36,
          "type" : "string",
          "format" : "uuid",
          "example" : "5bd3cb36-3688-e41b-45b4-24abb956e2c5"
        }
      },
      "certificateId" : {
        "name" : "certificateId",
        "in" : "path",
        "description" : "identifier of the referred Certificate",
        "required" : true,
        "style" : "simple",
        "explode" : false,
        "schema" : {
          "maxLength" : 36,
          "minLength" : 36,
          "type" : "string",
          "format" : "uuid",
          "example" : "ffe6404d-0589-e66c-f837-3e89cfe3d19a"
        }
      },
      "sposConfigId" : {
        "name" : "sposConfigId",
        "in" : "path",
        "description" : "identifier of the referred SposConfig",
        "required" : true,
        "style" : "simple",
        "explode" : false,
        "schema" : {
          "maxLength" : 36,
          "minLength" : 36,
          "type" : "string",
          "format" : "uuid",
          "example" : "f071b74c-ea66-b415-9a66-4ba06c637d13"
        }
      }
    },
    "requestBodies" : {
      "binaryELF" : {
        "description" : "Binary data of ELF to be uploaded as part of a request body.",
        "content" : {
          "multipart/form-data" : {
            "schema" : {
              "type" : "object",
              "properties" : {
                "elf-filename" : {
                  "type" : "string",
                  "description" : "filename of the ELF",
                  "example" : "elf-file.cap"
                },
                "elf-file" : {
                  "type" : "string",
                  "description" : "containing actual elf-file",
                  "format" : "binary"
                }
              }
            },
            "encoding" : {
              "elf-filename" : {
                "contentType" : "text/plain",
                "style" : "form"
              },
              "elf-file" : {
                "contentType" : "application/octet-stream",
                "style" : "form"
              }
            }
          }
        },
        "required" : true
      },
      "binaryPersoScript" : {
        "description" : "Binary data of a personalization script to be uploaded as part of a request body.",
        "content" : {
          "multipart/form-data" : {
            "schema" : {
              "type" : "object",
              "properties" : {
                "script-filename" : {
                  "type" : "string",
                  "description" : "filename of the personalization script",
                  "example" : "file.pers"
                },
                "script-file" : {
                  "type" : "string",
                  "description" : "containing actual script-file",
                  "format" : "binary"
                }
              }
            },
            "encoding" : {
              "script-filename" : {
                "contentType" : "text/plain",
                "style" : "form"
              },
              "script-file" : {
                "contentType" : "application/octet-stream",
                "style" : "form"
              }
            }
          }
        },
        "required" : true
      },
      "binaryCertificate" : {
        "description" : "Binary data of a certificate to be uploaded as part of a request body.",
        "content" : {
          "multipart/form-data" : {
            "schema" : {
              "type" : "object",
              "properties" : {
                "cert-filename" : {
                  "type" : "string",
                  "description" : "filename of the certificate",
                  "example" : "file.cert"
                },
                "cert-file" : {
                  "type" : "string",
                  "description" : "containing actual cert-file",
                  "format" : "binary"
                }
              }
            },
            "encoding" : {
              "cert-filename" : {
                "contentType" : "text/plain",
                "style" : "form"
              },
              "cert-file" : {
                "contentType" : "application/octet-stream",
                "style" : "form"
              }
            }
          }
        },
        "required" : true
      }
    },
    "securitySchemes" : {
      "LongtermToken" : {
        "type" : "http",
        "scheme" : "bearer"
      },
      "authToken" : {
        "type" : "http",
        "scheme" : "bearer"
      }
    }
  }
}