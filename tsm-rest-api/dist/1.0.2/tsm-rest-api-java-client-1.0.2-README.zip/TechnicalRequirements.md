# TechnicalRequirements

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**javaCardVersion** | **String** | Version of Java Card required by the CAP (&#x27;major.minor.patch&#x27;). |  [optional]
**gpApiVersion** | **String** | Version of GlobalPlatform API required by the CAP (&#x27;major.minor.patch&#x27;). |  [optional]
